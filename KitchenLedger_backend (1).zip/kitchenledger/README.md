# KitchenLedger – Backend API

Canteen Inventory Management System  
**Stack:** Python · FastAPI · PostgreSQL · JWT Auth

---

## Quick Start

### 1. Prerequisites
- Python 3.11+
- PostgreSQL 14+ running locally
- Create a database: `CREATE DATABASE inventory_management;`

### 2. Setup
```bash
# Clone / extract the project
cd backend

# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (Mac/Linux)
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env – set DB_PASSWORD and generate a SECRET_KEY:
# python -c "import secrets; print(secrets.token_hex(32))"
```

### 3. Run
```bash
# From the project root (one level above backend/)
python backend/run.py
```

The server starts at **http://localhost:8000**  
Swagger docs: **http://localhost:8000/docs**  
ReDoc: **http://localhost:8000/redoc**

> Tables, ENUMs, indexes, default categories, and the notifications table  
> are all created automatically on first startup.

---

## Project Structure

```
backend/
├── main.py               ← FastAPI app + router registration
├── run.py                ← Uvicorn entrypoint
├── dependencies.py       ← JWT auth + role guards (require_store / require_chef)
├── db_migrations.py      ← Idempotent migrations run at startup
│
├── config/
│   └── settings.py       ← Pydantic settings (reads .env)
│
├── connection/
│   ├── db_connection.py  ← psycopg2 connection pool + get_cursor()
│   └── db_schema.py      ← CREATE TABLE / ENUM / INDEX statements
│
├── schema/               ← Pydantic request & response models
│   ├── user.py
│   ├── category.py
│   ├── vendor.py
│   ├── product.py
│   ├── batch.py
│   ├── request_schema.py
│   └── notification.py
│
├── services/             ← Business logic (all DB access here)
│   ├── auth_service.py
│   ├── categories_service.py
│   ├── vendors_service.py
│   ├── products_service.py
│   ├── batches_service.py
│   ├── requests_service.py
│   ├── notifications_service.py
│   ├── stock_service.py
│   ├── reports_service.py
│   ├── dashboard_service.py
│   └── inventory_service.py
│
└── routes/               ← FastAPI routers (thin controllers)
    ├── auth.py
    ├── categories.py
    ├── vendors.py
    ├── products.py
    ├── batches.py
    ├── requests.py
    ├── stock_transactions.py
    ├── notifications.py
    ├── reports.py
    ├── dashboard.py
    └── inventory.py
```

---

## Roles

| Role    | Access |
|---------|--------|
| `store` | Create vendors, products, batches, requests. Edit/cancel own requests. |
| `chef`  | Approve / reject requests (triggers FIFO stock deduction). View all data. |

---

## Key API Endpoints

| Module | Prefix |
|--------|--------|
| Auth | `/api/auth` |
| Categories | `/api/categories` |
| Vendors | `/api/vendors` |
| Products | `/api/products` |
| Batches | `/api/batches` |
| Requests | `/api/requests` |
| Stock Transactions | `/api/stock-transactions` |
| Notifications | `/api/notifications` |
| Reports | `/api/reports` |
| Dashboard – Store | `/api/dashboard-store` |
| Dashboard – Chef | `/api/dashboard-chef` |
| Inventory | `/api/inventory` |

Import **KitchenLedger_API.postman_collection.json** into Postman for the full collection (44 requests).

---

## Security Notes

- All SQL queries use **parameterised statements** (`%s`) — zero injection risk.
- Dynamic UPDATE clauses are built from **hardcoded column allowlists** only.
- FIFO stock deduction uses **`SELECT ... FOR UPDATE`** row-locking to prevent race conditions.
- Soft deletes everywhere — no data is ever permanently removed unless explicitly required.
- Every state-changing operation writes to **audit_logs** inside the same transaction.
