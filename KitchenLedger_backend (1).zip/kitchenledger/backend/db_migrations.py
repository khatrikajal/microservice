"""
Run once at startup AFTER create_tables().
Adds columns / tables that are not in the original schema.
All statements are idempotent.
"""
from backend.connection.db_connection import get_connection

_DEFAULT_CATEGORIES = [
    "Grains", "Pulses", "Dairy", "Spices",
    "Oils", "Vegetables", "Beverages",
]


def run_migrations() -> None:
    conn = get_connection()
    cur = conn.cursor()
    try:
        # ── notifications table ──────────────────────────────────────────────
        cur.execute("""
            CREATE TABLE IF NOT EXISTS notifications (
                id          SERIAL PRIMARY KEY,
                user_id     INT  NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                title       VARCHAR(200) NOT NULL,
                message     TEXT,
                is_read     BOOLEAN   DEFAULT FALSE,
                entity_type VARCHAR(50),
                entity_id   INT,
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_notif_user_read
            ON notifications(user_id, is_read);
        """)

        # ── is_custom column on categories ───────────────────────────────────
        cur.execute("""
            DO $$ BEGIN
                ALTER TABLE categories ADD COLUMN is_custom BOOLEAN DEFAULT TRUE;
            EXCEPTION WHEN duplicate_column THEN NULL;
            END $$;
        """)

        # ── seed default categories (is_custom = FALSE, undeletable) ─────────
        for name in _DEFAULT_CATEGORIES:
            cur.execute("""
                INSERT INTO categories (name, is_custom, is_active)
                VALUES (%s, FALSE, TRUE)
                ON CONFLICT (name) DO UPDATE SET is_custom = FALSE;
            """, (name,))

        conn.commit()
        print("✓ Migrations applied successfully.")
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()
