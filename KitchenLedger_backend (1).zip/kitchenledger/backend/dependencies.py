"""
Centralised FastAPI dependencies.
- JWT validation (all protected routes)
- Role-based access control (store / chef)
"""
from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import List

import jwt

from backend.config.settings import settings
from backend.connection.db_connection import get_cursor

_bearer = HTTPBearer(auto_error=True)


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(_bearer),
) -> dict:
    """Decode JWT and return the authenticated user dict."""
    token = credentials.credentials
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM],
        )
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid authentication token")

    user_id = payload.get("sub")
    if user_id is None:
        raise HTTPException(status_code=401, detail="Invalid token payload")

    try:
        user_id = int(user_id)
    except (TypeError, ValueError):
        raise HTTPException(status_code=401, detail="Invalid token payload")

    with get_cursor() as cur:
        # Parameterised – no injection risk
        cur.execute(
            """
            SELECT id, name, email, role, contact, is_active, created_at
            FROM   users
            WHERE  id = %s
            """,
            (user_id,),
        )
        user = cur.fetchone()

    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    if not user["is_active"]:
        raise HTTPException(status_code=403, detail="Account is inactive")

    return dict(user)


class _RoleChecker:
    """Dependency that enforces one of the allowed roles."""

    def __init__(self, allowed: List[str]) -> None:
        self.allowed = allowed

    def __call__(self, current_user: dict = Depends(get_current_user)) -> dict:
        if current_user["role"] not in self.allowed:
            raise HTTPException(
                status_code=403,
                detail=f"Access denied. Allowed roles: {', '.join(self.allowed)}",
            )
        return current_user


# Reusable role guards
require_store = _RoleChecker(["store"])
require_chef  = _RoleChecker(["chef"])
require_any   = _RoleChecker(["store", "chef"])
