from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from backend.connection.db_connection import init_pool
from backend.connection.db_schema import create_tables
from backend.db_migrations import run_migrations

from backend.routes import (
    auth,
    categories,
    vendors,
    products,
    batches,
    requests,
    stock_transactions,
    notifications,
    reports,
    dashboard,
    inventory,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_pool()
    create_tables()       # original schema
    run_migrations()      # notifications table, is_custom col, default categories
    yield


app = FastAPI(
    title="KitchenLedger API",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routes ────────────────────────────────────────────────────────────────────
app.include_router(auth.router,                prefix="/api/auth",               tags=["Auth"])
app.include_router(categories.router,          prefix="/api/categories",          tags=["Categories"])
app.include_router(vendors.router,             prefix="/api/vendors",             tags=["Vendors"])
app.include_router(products.router,            prefix="/api/products",            tags=["Products"])
app.include_router(batches.router,             prefix="/api/batches",             tags=["Batches"])
app.include_router(requests.router,            prefix="/api/requests",            tags=["Requests"])
app.include_router(stock_transactions.router,  prefix="/api/stock-transactions",  tags=["Stock Transactions"])
app.include_router(notifications.router,       prefix="/api/notifications",       tags=["Notifications"])
app.include_router(reports.router,             prefix="/api/reports",             tags=["Reports"])
app.include_router(dashboard.router,           prefix="/api",                     tags=["Dashboard"])
app.include_router(inventory.router,           prefix="/api/inventory",           tags=["Inventory"])
