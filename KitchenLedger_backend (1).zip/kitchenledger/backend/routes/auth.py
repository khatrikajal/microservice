"""
Auth routes – matches the original project's auth.py structure.
Endpoints: POST /signup  POST /login  POST /logout  GET /me
"""
from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr, Field
from typing import Optional
import bcrypt
import jwt
from datetime import datetime, timezone, timedelta

from backend.config.settings import settings
from backend.connection.db_connection import get_cursor
from backend.dependencies import get_current_user

router  = APIRouter()
_bearer = HTTPBearer(auto_error=True)

# Simple in-process blocklist (replace with Redis in production)
_token_blocklist: set[str] = set()


# ── Pydantic models ───────────────────────────────────────────────────────────

class SignupRequest(BaseModel):
    name:     str   = Field(..., min_length=1, max_length=100, strip_whitespace=True)
    email:    str   = Field(..., max_length=100)
    password: str   = Field(..., min_length=8)
    contact:  Optional[str] = Field(None, max_length=50)
    role:     str   = Field(..., pattern="^(store|chef)$")


class LoginRequest(BaseModel):
    email:    str
    password: str


# ── Helpers ───────────────────────────────────────────────────────────────────

def _hash(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def _verify(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode(), hashed.encode())


def _make_token(user_id: int, role: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(
        minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
    )
    payload = {"sub": str(user_id), "role": role, "exp": expire}
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("/signup", status_code=201)
def signup(body: SignupRequest):
    with get_cursor(commit=True) as cur:
        cur.execute(
            "SELECT id FROM users WHERE email = %s",
            (body.email.lower(),),
        )
        if cur.fetchone():
            raise HTTPException(status_code=409, detail="Email already registered")

        cur.execute(
            """
            INSERT INTO users (name, email, role, password_hash, contact)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING id, name, email, role, contact, created_at
            """,
            (body.name, body.email.lower(), body.role, _hash(body.password), body.contact),
        )
        user = dict(cur.fetchone())
    return user


@router.post("/login")
def login(body: LoginRequest):
    with get_cursor() as cur:
        cur.execute(
            """
            SELECT id, name, email, role, password_hash, is_active
            FROM   users
            WHERE  email = %s
            """,
            (body.email.lower(),),
        )
        user = cur.fetchone()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if not user["is_active"]:
        raise HTTPException(status_code=403, detail="Account is inactive")
    if not _verify(body.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = _make_token(user["id"], user["role"])
    return {
        "access_token": token,
        "token_type":   "bearer",
        "user": {
            "id":    user["id"],
            "name":  user["name"],
            "email": user["email"],
            "role":  user["role"],
        },
    }


@router.post("/logout")
def logout(credentials: HTTPAuthorizationCredentials = Depends(_bearer)):
    token = credentials.credentials
    if token in _token_blocklist:
        raise HTTPException(status_code=400, detail="Token already invalid")
    _token_blocklist.add(token)
    return {"message": "Logged out successfully"}


@router.get("/me")
def me(current_user: dict = Depends(get_current_user)):
    return current_user
