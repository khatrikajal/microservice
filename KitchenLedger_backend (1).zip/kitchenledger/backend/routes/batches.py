from fastapi import APIRouter, Depends, Query
from typing import List, Optional, Union
from backend.schema.batch import BatchCreate
from backend.services import batches_service as svc
from backend.dependencies import require_store, require_any

router = APIRouter()


@router.get("")
def list_batches(
    product_id:       Optional[int] = Query(None, gt=0),
    vendor_id:        Optional[int] = Query(None, gt=0),
    expiring_within:  Optional[int] = Query(None, ge=1, le=365,
                                            description="Days until expiry"),
    page:             int           = Query(1,  ge=1),
    limit:            int           = Query(20, ge=1, le=100),
    _=Depends(require_any),
):
    return svc.list_batches(product_id, vendor_id, expiring_within, page, limit)


@router.get("/{product_id}")
def get_batches_by_product(product_id: int, _=Depends(require_any)):
    return svc.get_batch(product_id)


@router.post("", status_code=201)
def create_batch(
    body: Union[BatchCreate, List[BatchCreate]],
    current_user=Depends(require_store),
):
    """Accepts a single batch object OR an array for bulk intake."""
    if isinstance(body, list):
        return svc.create_batch_bulk(
            [b.model_dump() for b in body],
            current_user["id"],
        )
    return svc.create_batch(body.model_dump(), current_user["id"])
