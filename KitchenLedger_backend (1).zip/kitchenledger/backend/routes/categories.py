from fastapi import APIRouter, Depends
from backend.schema.category import CategoryCreate, CategoriesListOut
from backend.services import categories_service as svc
from backend.dependencies import require_store, require_any

router = APIRouter()


@router.get("", response_model=CategoriesListOut)
def list_categories(_=Depends(require_any)):
    return svc.list_categories()


@router.post("", status_code=201)
def create_category(body: CategoryCreate, current_user=Depends(require_store)):
    return svc.create_category(body.name, current_user["id"])


@router.delete("/{category_id}")
def delete_category(category_id: int, current_user=Depends(require_store)):
    return svc.delete_category(category_id, current_user["id"])
