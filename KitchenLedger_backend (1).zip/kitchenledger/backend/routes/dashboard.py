from fastapi import APIRouter, Depends, Query
from backend.services import dashboard_service as svc
from backend.dependencies import require_store, require_chef, require_any

router = APIRouter()


# ── Store Manager ─────────────────────────────────────────────────────────────

@router.get("/dashboard-store/cards")
def store_cards(_=Depends(require_store)):
    """Total stock value, expiring-soon count, pending requests count."""
    return svc.store_cards()


@router.get("/dashboard-store/expiry-alerts")
def store_expiry_alerts(
    days: int = Query(30, ge=1, le=365),
    _=Depends(require_any),          # both roles can view
):
    return svc.store_expiry_alerts(days)


# ── Chef / Admin ──────────────────────────────────────────────────────────────

@router.get("/dashboard-chef/cards")
def chef_cards(_=Depends(require_chef)):
    """Total / pending / approved / rejected request counts."""
    return svc.chef_cards()


@router.get("/dashboard-chef/pending")
def chef_pending(
    page:  int = Query(1,  ge=1),
    limit: int = Query(20, ge=1, le=100),
    _=Depends(require_chef),
):
    """Paginated pending-request queue sorted by priority."""
    return svc.chef_pending_requests(page, limit)


@router.get("/dashboard-chef/low-stock")
def chef_low_stock(_=Depends(require_any)):
    """Products below minimum stock level."""
    return svc.chef_low_stock()
