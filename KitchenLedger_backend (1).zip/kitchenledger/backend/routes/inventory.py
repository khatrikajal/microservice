from fastapi import APIRouter, Depends, Query
from typing import Optional
from backend.services import inventory_service as svc
from backend.dependencies import require_chef

router = APIRouter()


@router.get("/valuation")
def valuation(
    category: Optional[str] = Query(None, max_length=100),
    _=Depends(require_chef),
):
    """
    Total inventory value = SUM(quantity_available × unit_cost).
    Broken down by category. Chef role only.
    """
    return svc.valuation(category)
