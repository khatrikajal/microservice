from fastapi import APIRouter, Depends, Query
from typing import Optional
from backend.services import notifications_service as svc
from backend.dependencies import get_current_user

router = APIRouter()


@router.get("")
def list_notifications(
    read:  Optional[bool] = Query(None),
    page:  int            = Query(1,  ge=1),
    limit: int            = Query(20, ge=1, le=100),
    current_user=Depends(get_current_user),
):
    return svc.list_notifications(current_user["id"], read, page, limit)


@router.put("/read-all")
def mark_all_read(current_user=Depends(get_current_user)):
    return svc.mark_all_read(current_user["id"])


@router.put("/{notification_id}/read")
def mark_read(notification_id: int, current_user=Depends(get_current_user)):
    return svc.mark_read(notification_id, current_user["id"])
