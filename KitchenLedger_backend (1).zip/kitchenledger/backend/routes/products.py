from fastapi import APIRouter, Depends, Query
from typing import Optional
from backend.schema.product import ProductCreate, ProductUpdate
from backend.services import products_service as svc
from backend.dependencies import require_store, require_any

router = APIRouter()


@router.get("")
def list_products(
    category_id: Optional[int] = Query(None, gt=0),
    search:      Optional[str] = Query(None, max_length=100),
    page:        int           = Query(1,  ge=1),
    limit:       int           = Query(20, ge=1, le=100),
    _=Depends(require_any),
):
    return svc.list_products(category_id, search, page, limit)


@router.get("/{product_id}")
def get_product(product_id: int, _=Depends(require_any)):
    return svc.get_product(product_id)


@router.post("", status_code=201)
def create_product(body: ProductCreate, current_user=Depends(require_store)):
    return svc.create_product(body.model_dump(), current_user["id"])


@router.put("/{product_id}")
def update_product(product_id: int, body: ProductUpdate, current_user=Depends(require_store)):
    return svc.update_product(product_id, body.model_dump(exclude_unset=True), current_user["id"])


@router.delete("/{product_id}")
def delete_product(product_id: int, current_user=Depends(require_store)):
    return svc.delete_product(product_id, current_user["id"])
