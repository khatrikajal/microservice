from fastapi import APIRouter, Depends, Query
from typing import Optional
from datetime import date
from backend.services import reports_service as svc
from backend.dependencies import require_any, get_current_user

router = APIRouter()


@router.get("/summary")
def summary(current_user=Depends(require_any)):
    return svc.summary(current_user["role"])


@router.get("/stock")
def stock_report(
    category:   Optional[str]  = Query(None, max_length=100),
    low_stock:  Optional[bool] = Query(None),
    start_date: Optional[date] = Query(None),
    end_date:   Optional[date] = Query(None),
    _=Depends(require_any),
):
    return svc.stock_report(category, low_stock, start_date, end_date)


@router.get("/vendor")
def vendor_report(
    vendor_id:  Optional[int]  = Query(None, gt=0),
    start_date: Optional[date] = Query(None),
    end_date:   Optional[date] = Query(None),
    _=Depends(require_any),
):
    return svc.vendor_report(vendor_id, start_date, end_date)


@router.get("/category")
def category_report(
    start_date: Optional[date] = Query(None),
    end_date:   Optional[date] = Query(None),
    _=Depends(require_any),
):
    return svc.category_report(start_date, end_date)


@router.get("/consumption")
def consumption_report(
    product_id: Optional[int]  = Query(None, gt=0),
    group_by:   str            = Query("day", pattern="^(day|week|month)$"),
    start_date: Optional[date] = Query(None),
    end_date:   Optional[date] = Query(None),
    _=Depends(require_any),
):
    return svc.consumption_report(product_id, group_by, start_date, end_date)


@router.get("/expiry")
def expiry_report(
    status: Optional[str] = Query(None, pattern="^(expired|expiring)$"),
    days:   int           = Query(30, ge=1, le=365),
    _=Depends(require_any),
):
    return svc.expiry_report(status, days)


@router.get("/card")
def card_report(_=Depends(require_any)):
    return svc.card_report()
