from fastapi import APIRouter, Depends, Query
from typing import Optional
from datetime import date
from backend.schema.request_schema import RequestCreate, RequestStoreUpdate, RequestChefAction
from backend.services import requests_service as svc
from backend.dependencies import require_store, require_chef, require_any, get_current_user

router = APIRouter()


@router.get("/pending-count")
def pending_count(_=Depends(require_chef)):
    """Lightweight badge count for chef dashboard."""
    return svc.pending_count()


@router.get("")
def list_requests(
    status:     Optional[str]  = Query(None),
    product_id: Optional[int]  = Query(None, gt=0),
    start_date: Optional[date] = Query(None),
    end_date:   Optional[date] = Query(None),
    page:       int            = Query(1,  ge=1),
    limit:      int            = Query(20, ge=1, le=100),
    current_user=Depends(require_any),
):
    return svc.list_requests(current_user, status, product_id, start_date, end_date, page, limit)


@router.get("/{request_id}")
def get_request(request_id: int, current_user=Depends(require_any)):
    return svc.get_request(request_id, current_user)


@router.post("", status_code=201)
def create_request(body: RequestCreate, current_user=Depends(require_store)):
    return svc.create_request(body.model_dump(), current_user["id"])


@router.patch("/{request_id}")
def patch_request(
    request_id: int,
    body: RequestStoreUpdate | RequestChefAction,
    current_user=Depends(get_current_user),
):
    """
    Store (status=pending only): edit reason / priority.
    Chef: approve / reject with optional per-item quantities.
    """
    return svc.patch_request(request_id, body.model_dump(exclude_unset=True), current_user)


@router.delete("/{request_id}")
def cancel_request(request_id: int, current_user=Depends(require_store)):
    return svc.cancel_request(request_id, current_user["id"])
