from fastapi import APIRouter, Depends, Query
from typing import Optional
from datetime import date
from backend.services import stock_service as svc
from backend.dependencies import require_any

router = APIRouter()


@router.get("")
def list_transactions(
    type:       Optional[str]  = Query(None, description="issue or purchase"),
    product_id: Optional[int]  = Query(None, gt=0),
    start_date: Optional[date] = Query(None),
    end_date:   Optional[date] = Query(None),
    page:       int            = Query(1,  ge=1),
    limit:      int            = Query(20, ge=1, le=100),
    _=Depends(require_any),
):
    return svc.list_transactions(type, product_id, start_date, end_date, page, limit)
