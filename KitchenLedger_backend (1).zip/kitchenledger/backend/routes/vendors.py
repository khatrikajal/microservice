from fastapi import APIRouter, Depends, Query
from typing import Optional
from backend.schema.vendor import VendorCreate, VendorUpdate
from backend.services import vendors_service as svc
from backend.dependencies import require_store, require_any

router = APIRouter()


@router.get("")
def list_vendors(
    search: Optional[str] = Query(None, max_length=100),
    page:   int           = Query(1,  ge=1),
    limit:  int           = Query(20, ge=1, le=100),
    _=Depends(require_any),
):
    return svc.list_vendors(search, page, limit)


@router.get("/{vendor_id}")
def get_vendor(vendor_id: int, _=Depends(require_any)):
    return svc.get_vendor(vendor_id)


@router.post("", status_code=201)
def create_vendor(body: VendorCreate, current_user=Depends(require_store)):
    return svc.create_vendor(body.model_dump(), current_user["id"])


@router.put("/{vendor_id}")
def update_vendor(vendor_id: int, body: VendorUpdate, current_user=Depends(require_store)):
    return svc.update_vendor(vendor_id, body.model_dump(exclude_unset=True), current_user["id"])


@router.delete("/{vendor_id}")
def delete_vendor(vendor_id: int, current_user=Depends(require_store)):
    return svc.delete_vendor(vendor_id, current_user["id"])
