from pydantic import BaseModel, Field, model_validator
from typing import List, Optional
from datetime import date, datetime
from decimal import Decimal


class BatchCreate(BaseModel):
    product_id: int = Field(..., gt=0)
    vendor_id: int = Field(..., gt=0)
    quantity: int = Field(..., gt=0)
    unit_cost: Optional[Decimal] = Field(None, ge=0)
    purchase_date: Optional[date] = None
    expiry_date: Optional[date] = None

    @model_validator(mode="after")
    def expiry_after_purchase(self):
        if self.expiry_date and self.purchase_date:
            if self.expiry_date < self.purchase_date:
                raise ValueError("expiry_date must be after purchase_date")
        return self


class BatchOut(BaseModel):
    id: int
    product_id: int
    product_name: Optional[str]
    vendor_id: Optional[int]
    vendor_name: Optional[str]
    quantity: int
    quantity_available: int
    unit_cost: Optional[Decimal]
    total_cost: Optional[Decimal]
    purchase_date: Optional[date]
    expiry_date: Optional[date]
    created_at: datetime


class BatchesListOut(BaseModel):
    data: List[BatchOut]
    total: int
    page: int
    limit: int
