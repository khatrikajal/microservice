from pydantic import BaseModel, Field
from typing import List


class CategoryCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, strip_whitespace=True)


class CategoryOut(BaseModel):
    id: int
    name: str
    is_active: bool
    is_custom: bool


class CategoriesListOut(BaseModel):
    defaults: List[CategoryOut]
    custom: List[CategoryOut]
    all: List[CategoryOut]
