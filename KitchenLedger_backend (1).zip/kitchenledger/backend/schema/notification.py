from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime


class NotificationOut(BaseModel):
    id: int
    user_id: int
    title: str
    message: Optional[str]
    is_read: bool
    entity_type: Optional[str]
    entity_id: Optional[int]
    created_at: datetime


class NotificationsListOut(BaseModel):
    data: List[NotificationOut]
    unread_count: int
    total: int
    page: int
    limit: int
