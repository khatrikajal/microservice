from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime


class ProductCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, strip_whitespace=True)
    category_id: int = Field(..., gt=0)
    brand_name: Optional[str] = Field(None, max_length=50)
    unit: str = Field(..., max_length=20)
    shelf_life_days: Optional[int] = Field(None, gt=0)
    min_stock_level: int = Field(0, ge=0)


class ProductUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=100, strip_whitespace=True)
    category_id: Optional[int] = Field(None, gt=0)
    brand_name: Optional[str] = Field(None, max_length=50)
    unit: Optional[str] = Field(None, max_length=20)
    shelf_life_days: Optional[int] = Field(None, gt=0)
    min_stock_level: Optional[int] = Field(None, ge=0)


class BatchSummary(BaseModel):
    id: int
    quantity: int
    quantity_available: int
    expiry_date: Optional[str]
    purchase_date: Optional[str]


class ProductOut(BaseModel):
    id: int
    name: str
    category_id: Optional[int]
    category_name: Optional[str]
    brand_name: Optional[str]
    unit: Optional[str]
    shelf_life_days: Optional[int]
    min_stock_level: int
    is_active: bool
    created_at: datetime
    total_stock: float = 0.0
    batches: Optional[List[BatchSummary]] = None


class ProductsListOut(BaseModel):
    data: List[ProductOut]
    total: int
    page: int
    limit: int
