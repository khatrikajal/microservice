from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import date, datetime
from enum import Enum


class PriorityLevel(str, Enum):
    high   = "high"
    medium = "medium"
    low    = "low"


class ApprovalStatusEnum(str, Enum):
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    MODIFIED = "MODIFIED"


class RequestItemCreate(BaseModel):
    product_id: int = Field(..., gt=0)
    requested_quantity: int = Field(..., gt=0)


class RequestCreate(BaseModel):
    items: List[RequestItemCreate] = Field(..., min_length=1)
    reason: Optional[str] = None
    priority: PriorityLevel = PriorityLevel.medium
    request_date: Optional[date] = None


class RequestStoreUpdate(BaseModel):
    reason: Optional[str] = None
    priority: Optional[PriorityLevel] = None


class ItemApproval(BaseModel):
    request_item_id: int = Field(..., gt=0)
    approved_quantity: int = Field(..., ge=0)


class RequestChefAction(BaseModel):
    approval_status: ApprovalStatusEnum
    remarks: Optional[str] = None
    item_approvals: Optional[List[ItemApproval]] = None   # per-item approved qty


class RequestItemOut(BaseModel):
    id: int
    product_id: int
    product_name: Optional[str]
    requested_quantity: int
    approved_quantity: Optional[int]
    fulfilled_quantity: int


class RequestOut(BaseModel):
    id: int
    requested_by: Optional[int]
    requester_name: Optional[str]
    status: str
    priority: str
    reason: Optional[str]
    request_date: Optional[date]
    created_at: datetime
    items: List[RequestItemOut] = []


class RequestsListOut(BaseModel):
    data: List[RequestOut]
    total: int
    page: int
    limit: int
