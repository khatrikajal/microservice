from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class UserOut(BaseModel):
    id: int
    name: str
    email: str
    role: str
    contact: Optional[str]
    is_active: bool
    created_at: datetime
