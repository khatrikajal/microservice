from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime


class VendorCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, strip_whitespace=True)
    contact: Optional[str] = Field(None, max_length=50)
    address: Optional[str] = None
    supplied_items: Optional[List[str]] = []


class VendorUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=100, strip_whitespace=True)
    contact: Optional[str] = Field(None, max_length=50)
    address: Optional[str] = None
    supplied_items: Optional[List[str]] = None


class VendorOut(BaseModel):
    id: int
    name: str
    contact: Optional[str]
    address: Optional[str]
    is_active: bool
    created_at: datetime
    supplied_items: List[str] = []


class VendorsListOut(BaseModel):
    data: List[VendorOut]
    total: int
    page: int
    limit: int
