"""
KitchenLedger – Database Seeder
================================
Inserts realistic mock data into every table in FK-safe order.

Usage (from project root):
    python backend/seed.py

Flags:
    --reset    Wipe all existing data before seeding (TRUNCATE CASCADE)
    --quiet    Suppress row-level output

Example:
    python backend/seed.py --reset
"""

import sys
import argparse
from datetime import date, timedelta
import bcrypt

# ── Make sure backend package is importable ───────────────────────────────────
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.connection.db_connection import init_pool, get_connection
from backend.connection.db_schema import create_tables
from backend.db_migrations import run_migrations

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def hpw(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


today        = date.today()
d            = lambda n: today + timedelta(days=n)  # relative date helper


def log(msg: str, quiet: bool):
    if not quiet:
        print(msg)


# ─────────────────────────────────────────────────────────────────────────────
# SEED FUNCTIONS  (each returns list of inserted IDs)
# ─────────────────────────────────────────────────────────────────────────────

def seed_users(cur, quiet) -> dict:
    """2 store managers + 2 chefs."""
    users = [
        ("Rahul Sharma",   "rahul@kitchen.com",   "store", hpw("Store@1234")),
        ("Priya Mehta",    "priya@kitchen.com",   "store", hpw("Store@1234")),
        ("Chef Arjun",     "arjun@kitchen.com",   "chef",  hpw("Chef@1234")),
        ("Chef Sneha",     "sneha@kitchen.com",   "chef",  hpw("Chef@1234")),
    ]
    ids = {}
    for name, email, role, pw in users:
        cur.execute(
            """
            INSERT INTO users (name, email, role, password_hash, contact, is_active)
            VALUES (%s, %s, %s, %s, %s, TRUE)
            ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name
            RETURNING id, name
            """,
            (name, email, role, pw, "9800000001"),
        )
        row = cur.fetchone()
        ids[email] = row["id"]
        log(f"  👤  User       [{row['id']:>3}] {name} ({role})", quiet)
    return ids


def seed_categories(cur, quiet) -> dict:
    """Default categories already seeded by migration; add 2 custom ones."""
    custom = ["Frozen Foods", "Condiments"]
    ids = {}

    # Fetch all (defaults already exist)
    cur.execute("SELECT id, name FROM categories WHERE is_active = TRUE")
    for row in cur.fetchall():
        ids[row["name"]] = row["id"]

    for name in custom:
        cur.execute(
            """
            INSERT INTO categories (name, is_custom, is_active)
            VALUES (%s, TRUE, TRUE)
            ON CONFLICT (name) DO UPDATE SET is_custom = TRUE
            RETURNING id, name
            """,
            (name,),
        )
        row = cur.fetchone()
        ids[row["name"]] = row["id"]
        log(f"  🏷️   Category   [{row['id']:>3}] {name}", quiet)

    return ids


def seed_vendors(cur, quiet) -> dict:
    vendors = [
        ("Fresh Farms Ltd",      "9811111111", "Plot 12, APMC Yard, Nashik"),
        ("Spice World Traders",  "9822222222", "Shop 5, Spice Market, Mumbai"),
        ("DairyBest Pvt Ltd",    "9833333333", "Sector 9, Milk Colony, Pune"),
        ("GrainMart Wholesale",  "9844444444", "Warehouse 3, Deolali, Nashik"),
        ("OilKing Distributors", "9855555555", "Industrial Area, Malegaon"),
    ]
    ids = {}
    for name, contact, address in vendors:
        cur.execute(
            """
            INSERT INTO vendors (name, contact, address, is_active)
            VALUES (%s, %s, %s, TRUE)
            ON CONFLICT DO NOTHING
            RETURNING id, name
            """,
            (name, contact, address),
        )
        row = cur.fetchone()
        if row:
            ids[name] = row["id"]
            log(f"  🏪  Vendor     [{row['id']:>3}] {name}", quiet)
        else:
            cur.execute("SELECT id FROM vendors WHERE name = %s", (name,))
            ids[name] = cur.fetchone()["id"]
    return ids


def seed_products(cur, cat, quiet) -> dict:
    products = [
        # (name,               category,    unit,   shelf_life, min_stock, brand)
        ("Basmati Rice",       "Grains",    "KG",   365,        50,  "India Gate"),
        ("Wheat Flour (Atta)", "Grains",    "KG",   180,        30,  "Aashirvaad"),
        ("Toor Dal",           "Pulses",    "KG",   270,        25,  "Tata Sampann"),
        ("Chana Dal",          "Pulses",    "KG",   270,        20,  "24 Mantra"),
        ("Full Cream Milk",    "Dairy",     "Litre",7,          40,  "Amul"),
        ("Paneer",             "Dairy",     "KG",   10,         10,  "Amul"),
        ("Ghee",               "Dairy",     "Litre",365,        5,   "Mother Dairy"),
        ("Cumin Seeds",        "Spices",    "KG",   540,        5,   "Everest"),
        ("Coriander Powder",   "Spices",    "KG",   365,        4,   "MDH"),
        ("Turmeric Powder",    "Spices",    "KG",   540,        3,   "Catch"),
        ("Red Chilli Powder",  "Spices",    "KG",   365,        3,   "Everest"),
        ("Sunflower Oil",      "Oils",      "Litre",365,        20,  "Fortune"),
        ("Mustard Oil",        "Oils",      "Litre",365,        10,  "Dhara"),
        ("Tomatoes",           "Vegetables","KG",   7,          15,  None),
        ("Onions",             "Vegetables","KG",   30,         20,  None),
        ("Potatoes",           "Vegetables","KG",   30,         20,  None),
        ("Green Peas",         "Vegetables","KG",   5,          8,   None),
        ("Tea (CTC)",          "Beverages", "KG",   365,        5,   "Brooke Bond"),
        ("Coffee Powder",      "Beverages", "KG",   365,        3,   "Bru"),
        ("Frozen Peas",        "Frozen Foods","KG", 180,        10,  "McCain"),
        ("Soy Sauce",          "Condiments","Litre",365,        3,   "Maggi"),
    ]
    ids = {}
    for name, category, unit, shelf, min_s, brand in products:
        cat_id = cat.get(category)
        cur.execute(
            """
            INSERT INTO products
                   (name, category_id, unit, shelf_life_days, min_stock_level, brand_name, is_active)
            VALUES (%s, %s, %s, %s, %s, %s, TRUE)
            ON CONFLICT DO NOTHING
            RETURNING id, name
            """,
            (name, cat_id, unit, shelf, min_s, brand),
        )
        row = cur.fetchone()
        if row:
            ids[name] = row["id"]
            log(f"  📦  Product    [{row['id']:>3}] {name}", quiet)
        else:
            cur.execute("SELECT id FROM products WHERE name = %s AND is_active = TRUE", (name,))
            ids[name] = cur.fetchone()["id"]
    return ids


def seed_vendor_products(cur, ven, prod, quiet):
    links = [
        ("Fresh Farms Ltd",      "Tomatoes",           18.0),
        ("Fresh Farms Ltd",      "Onions",             25.0),
        ("Fresh Farms Ltd",      "Potatoes",           22.0),
        ("Fresh Farms Ltd",      "Green Peas",         60.0),
        ("GrainMart Wholesale",  "Basmati Rice",       85.0),
        ("GrainMart Wholesale",  "Wheat Flour (Atta)", 42.0),
        ("GrainMart Wholesale",  "Toor Dal",           105.0),
        ("GrainMart Wholesale",  "Chana Dal",          90.0),
        ("Spice World Traders",  "Cumin Seeds",        320.0),
        ("Spice World Traders",  "Coriander Powder",   180.0),
        ("Spice World Traders",  "Turmeric Powder",    140.0),
        ("Spice World Traders",  "Red Chilli Powder",  190.0),
        ("DairyBest Pvt Ltd",    "Full Cream Milk",    58.0),
        ("DairyBest Pvt Ltd",    "Paneer",             360.0),
        ("DairyBest Pvt Ltd",    "Ghee",               520.0),
        ("OilKing Distributors", "Sunflower Oil",      135.0),
        ("OilKing Distributors", "Mustard Oil",        145.0),
        ("Spice World Traders",  "Tea (CTC)",          280.0),
        ("Spice World Traders",  "Coffee Powder",      480.0),
        ("Fresh Farms Ltd",      "Frozen Peas",        95.0),
        ("Spice World Traders",  "Soy Sauce",          110.0),
    ]
    for v_name, p_name, cost in links:
        v_id = ven.get(v_name)
        p_id = prod.get(p_name)
        if v_id and p_id:
            cur.execute(
                """
                INSERT INTO vendor_products (vendor_id, product_id, unit_cost, is_active)
                VALUES (%s, %s, %s, TRUE)
                ON CONFLICT (vendor_id, product_id)
                DO UPDATE SET unit_cost = EXCLUDED.unit_cost
                """,
                (v_id, p_id, cost),
            )
    log(f"  🔗  vendor_products  {len(links)} links upserted", quiet)


def seed_batches(cur, ven, prod, user_ids, quiet) -> list:
    """
    Batches: mix of healthy stock, low stock, and expiring-soon/expired.
    quantity_available is intentionally lower on some rows to simulate usage.
    """
    store_id = list(user_ids.values())[0]   # first store user performed purchases

    batches = [
        # product,               vendor,                  qty, avail, cost,   purchase,    expiry
        ("Basmati Rice",       "GrainMart Wholesale",   200, 165,  85.0,  d(-60),  d(305)),
        ("Basmati Rice",       "GrainMart Wholesale",   100,  80,  87.0,  d(-20),  d(345)),
        ("Wheat Flour (Atta)", "GrainMart Wholesale",   150, 120,  42.0,  d(-45),  d(135)),
        ("Wheat Flour (Atta)", "GrainMart Wholesale",    80,  15,  44.0,  d(-10),  d(170)),  # low avail
        ("Toor Dal",           "GrainMart Wholesale",   100,  90, 105.0,  d(-30),  d(240)),
        ("Chana Dal",          "GrainMart Wholesale",    60,  55,  90.0,  d(-15),  d(255)),
        ("Full Cream Milk",    "DairyBest Pvt Ltd",      80,   8,  58.0,  d(-5),   d(2)),    # expiring very soon
        ("Full Cream Milk",    "DairyBest Pvt Ltd",      60,  60,  58.0,  d(-1),   d(6)),
        ("Paneer",             "DairyBest Pvt Ltd",      30,   5, 360.0,  d(-8),   d(2)),    # expiring
        ("Ghee",               "DairyBest Pvt Ltd",      20,  18, 520.0,  d(-90),  d(275)),
        ("Cumin Seeds",        "Spice World Traders",    15,  13, 320.0,  d(-120), d(420)),
        ("Coriander Powder",   "Spice World Traders",    10,   9, 180.0,  d(-60),  d(305)),
        ("Turmeric Powder",    "Spice World Traders",    12,  11, 140.0,  d(-45),  d(495)),
        ("Red Chilli Powder",  "Spice World Traders",    10,   2, 190.0,  d(-90),  d(275)),  # low
        ("Sunflower Oil",      "OilKing Distributors",   50,  45, 135.0,  d(-30),  d(335)),
        ("Mustard Oil",        "OilKing Distributors",   30,   3, 145.0,  d(-60),  d(305)),  # low
        ("Tomatoes",           "Fresh Farms Ltd",        40,   0,  18.0,  d(-10),  d(-3)),   # EXPIRED & exhausted
        ("Onions",             "Fresh Farms Ltd",        60,  50,  25.0,  d(-20),  d(10)),
        ("Potatoes",           "Fresh Farms Ltd",        80,  65,  22.0,  d(-15),  d(15)),
        ("Green Peas",         "Fresh Farms Ltd",        25,   4,  60.0,  d(-6),   d(-1)),   # EXPIRED
        ("Tea (CTC)",          "Spice World Traders",    20,  17, 280.0,  d(-90),  d(275)),
        ("Coffee Powder",      "Spice World Traders",    10,   9, 480.0,  d(-60),  d(305)),
        ("Frozen Peas",        "Fresh Farms Ltd",        30,  28,  95.0,  d(-10),  d(170)),
        ("Soy Sauce",          "Spice World Traders",    12,  11, 110.0,  d(-30),  d(335)),
    ]

    batch_ids = []
    for p_name, v_name, qty, avail, cost, pdate, edate in batches:
        p_id = prod.get(p_name)
        v_id = ven.get(v_name)
        if not p_id or not v_id:
            continue
        cur.execute(
            """
            INSERT INTO inventory_batches
                   (product_id, vendor_id, quantity, quantity_available,
                    unit_cost, purchase_date, expiry_date)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            RETURNING id
            """,
            (p_id, v_id, qty, avail, cost, pdate, edate),
        )
        bid = cur.fetchone()["id"]
        batch_ids.append(bid)

        # Create a PURCHASE stock_transaction for each batch
        cur.execute(
            """
            INSERT INTO stock_transactions
                   (batch_id, product_id, transaction_type, quantity, performed_by, created_at)
            VALUES (%s, %s, 'PURCHASE', %s, %s, NOW() - INTERVAL '1 day' * %s)
            """,
            (bid, p_id, qty, store_id, abs((pdate - today).days)),
        )

        issued = qty - avail
        if issued > 0:
            cur.execute(
                """
                INSERT INTO stock_transactions
                       (batch_id, product_id, transaction_type, quantity, performed_by,
                        created_at)
                VALUES (%s, %s, 'ISSUE', %s, %s, NOW() - INTERVAL '1 hour' * %s)
                """,
                (bid, p_id, issued, store_id, abs((pdate - today).days) * 2),
            )

        log(f"  📥  Batch      [{bid:>3}] {p_name:<25} qty={qty:>3} avail={avail:>3}  exp={edate}", quiet)

    return batch_ids


def seed_requests(cur, prod, user_ids, quiet) -> list:
    """
    Requests covering all statuses: PENDING, APPROVED, REJECTED.
    """
    users   = list(user_ids.values())
    store1  = users[0]   # rahul
    store2  = users[1]   # priya
    chef1   = users[2]   # arjun
    chef2   = users[3]   # sneha

    req_ids = []

    # ── 1. APPROVED request (older, already fulfilled) ─────────────────────────
    cur.execute(
        """
        INSERT INTO requests (requested_by, status, priority, reason, request_date, created_at)
        VALUES (%s, 'APPROVED', 'high',
                'Weekly vegetable replenishment for main kitchen',
                %s, NOW() - INTERVAL '10 days')
        RETURNING id
        """,
        (store1, d(-10)),
    )
    r1 = cur.fetchone()["id"]
    req_ids.append(r1)

    items_r1 = [
        (prod["Onions"],   30, 30, 30),
        (prod["Tomatoes"], 20, 20, 0),    # expired so fulfilled=0
        (prod["Potatoes"], 25, 25, 25),
    ]
    for p_id, req_q, app_q, ful_q in items_r1:
        cur.execute(
            """
            INSERT INTO request_items
                   (request_id, product_id, requested_quantity, approved_quantity, fulfilled_quantity)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING id
            """,
            (r1, p_id, req_q, app_q, ful_q),
        )
        ri_id = cur.fetchone()["id"]
        if ful_q > 0:
            # Find a batch for this product and create ISSUE transaction
            cur.execute(
                """
                SELECT id FROM inventory_batches
                WHERE product_id = %s AND quantity_available >= 0
                ORDER BY purchase_date ASC LIMIT 1
                """,
                (p_id,),
            )
            batch = cur.fetchone()
            if batch:
                cur.execute(
                    """
                    INSERT INTO stock_transactions
                           (batch_id, product_id, request_item_id,
                            transaction_type, quantity, performed_by,
                            created_at)
                    VALUES (%s, %s, %s, 'ISSUE', %s, %s, NOW() - INTERVAL '9 days')
                    """,
                    (batch["id"], p_id, ri_id, ful_q, chef1),
                )

    cur.execute(
        """
        INSERT INTO request_approvals
               (request_id, approved_by, approval_status, remarks, approval_date)
        VALUES (%s, %s, 'APPROVED', 'All items available in stock', NOW() - INTERVAL '9 days')
        """,
        (r1, chef1),
    )
    log(f"  📋  Request    [{r1:>3}] APPROVED  (10 days ago)", quiet)

    # ── 2. REJECTED request ────────────────────────────────────────────────────
    cur.execute(
        """
        INSERT INTO requests (requested_by, status, priority, reason, request_date, created_at)
        VALUES (%s, 'REJECTED', 'low',
                'Extra ghee for festive cooking',
                %s, NOW() - INTERVAL '7 days')
        RETURNING id
        """,
        (store2, d(-7)),
    )
    r2 = cur.fetchone()["id"]
    req_ids.append(r2)
    cur.execute(
        """
        INSERT INTO request_items
               (request_id, product_id, requested_quantity, approved_quantity, fulfilled_quantity)
        VALUES (%s, %s, 10, 0, 0)
        """,
        (r2, prod["Ghee"]),
    )
    cur.execute(
        """
        INSERT INTO request_approvals
               (request_id, approved_by, approval_status, remarks, approval_date)
        VALUES (%s, %s, 'REJECTED', 'Sufficient ghee already in stock', NOW() - INTERVAL '6 days')
        """,
        (r2, chef2),
    )
    log(f"  📋  Request    [{r2:>3}] REJECTED  (7 days ago)", quiet)

    # ── 3. PENDING request – high priority ────────────────────────────────────
    cur.execute(
        """
        INSERT INTO requests (requested_by, status, priority, reason, request_date, created_at)
        VALUES (%s, 'PENDING', 'high',
                'Urgent – dairy stock critically low before weekend',
                %s, NOW() - INTERVAL '1 hour')
        RETURNING id
        """,
        (store1, today),
    )
    r3 = cur.fetchone()["id"]
    req_ids.append(r3)
    for p_id, qty in [(prod["Full Cream Milk"], 80), (prod["Paneer"], 15)]:
        cur.execute(
            """
            INSERT INTO request_items
                   (request_id, product_id, requested_quantity)
            VALUES (%s, %s, %s)
            """,
            (r3, p_id, qty),
        )
    log(f"  📋  Request    [{r3:>3}] PENDING   high priority (1 hour ago)", quiet)

    # ── 4. PENDING request – medium priority ──────────────────────────────────
    cur.execute(
        """
        INSERT INTO requests (requested_by, status, priority, reason, request_date, created_at)
        VALUES (%s, 'PENDING', 'medium',
                'Monthly spice restocking',
                %s, NOW() - INTERVAL '3 hours')
        RETURNING id
        """,
        (store2, today),
    )
    r4 = cur.fetchone()["id"]
    req_ids.append(r4)
    for p_id, qty in [
        (prod["Cumin Seeds"], 5),
        (prod["Coriander Powder"], 4),
        (prod["Turmeric Powder"], 3),
        (prod["Red Chilli Powder"], 5),
    ]:
        cur.execute(
            """
            INSERT INTO request_items
                   (request_id, product_id, requested_quantity)
            VALUES (%s, %s, %s)
            """,
            (r4, p_id, qty),
        )
    log(f"  📋  Request    [{r4:>3}] PENDING   medium priority (3 hours ago)", quiet)

    # ── 5. PENDING request – low priority ─────────────────────────────────────
    cur.execute(
        """
        INSERT INTO requests (requested_by, status, priority, reason, request_date, created_at)
        VALUES (%s, 'PENDING', 'low',
                'Top-up oils before end of month',
                %s, NOW() - INTERVAL '30 minutes')
        RETURNING id
        """,
        (store1, today),
    )
    r5 = cur.fetchone()["id"]
    req_ids.append(r5)
    for p_id, qty in [(prod["Sunflower Oil"], 20), (prod["Mustard Oil"], 10)]:
        cur.execute(
            """
            INSERT INTO request_items
                   (request_id, product_id, requested_quantity)
            VALUES (%s, %s, %s)
            """,
            (r5, p_id, qty),
        )
    log(f"  📋  Request    [{r5:>3}] PENDING   low priority (30 min ago)", quiet)

    return req_ids


def seed_notifications(cur, user_ids, req_ids, quiet):
    users  = list(user_ids.values())
    store1 = users[0]
    store2 = users[1]
    chef1  = users[2]
    chef2  = users[3]

    notifs = [
        # user_id, title, message, entity_type, entity_id, is_read
        (chef1,  "New Stock Request",
         "A new high-priority stock request has been submitted by Rahul Sharma.",
         "requests", req_ids[2], False),

        (chef2,  "New Stock Request",
         "A new high-priority stock request has been submitted by Rahul Sharma.",
         "requests", req_ids[2], False),

        (chef1,  "New Stock Request",
         "Monthly spice restocking request submitted by Priya Mehta.",
         "requests", req_ids[3], False),

        (chef2,  "New Stock Request",
         "Monthly spice restocking request submitted by Priya Mehta.",
         "requests", req_ids[3], True),

        (store1, "Request APPROVED",
         "Your weekly vegetable replenishment request has been approved.",
         "requests", req_ids[0], True),

        (store2, "Request REJECTED",
         "Your ghee request was rejected. Sufficient stock already available.",
         "requests", req_ids[1], True),

        (chef1,  "New Stock Received",
         "A new batch of 200 units of Basmati Rice has been added to inventory.",
         "inventory_batches", 1, True),

        (store1, "⚠ Low Stock Alert",
         "Red Chilli Powder is below minimum stock level (2 units remaining).",
         None, None, False),

        (store2, "⚠ Expiry Alert",
         "Full Cream Milk batch is expiring in 2 days. Take action immediately.",
         None, None, False),

        (chef1,  "⚠ Expiry Alert",
         "Paneer batch expires in 2 days – use or discard.",
         None, None, False),
    ]

    for user_id, title, message, entity_type, entity_id, is_read in notifs:
        cur.execute(
            """
            INSERT INTO notifications
                   (user_id, title, message, entity_type, entity_id, is_read)
            VALUES (%s, %s, %s, %s, %s, %s)
            """,
            (user_id, title, message, entity_type, entity_id, is_read),
        )
    log(f"  🔔  Notifications  {len(notifs)} inserted", quiet)


def seed_audit_logs(cur, user_ids, quiet):
    users  = list(user_ids.values())
    store1 = users[0]
    chef1  = users[2]

    logs = [
        (store1, "CREATE", "vendors",  1, "Created vendor 'Fresh Farms Ltd'"),
        (store1, "CREATE", "vendors",  2, "Created vendor 'Spice World Traders'"),
        (store1, "CREATE", "products", 1, "Created product 'Basmati Rice'"),
        (store1, "CREATE", "products", 5, "Created product 'Full Cream Milk'"),
        (store1, "CREATE", "inventory_batches", 1, "Stock purchase: product_id=1, qty=200"),
        (chef1,  "UPDATE", "requests", 1, "Chef set status=APPROVED"),
        (chef1,  "UPDATE", "requests", 2, "Chef set status=REJECTED"),
        (store1, "CREATE", "requests", 3, "Created request with 2 item(s)"),
    ]

    for user_id, action, entity, entity_id, desc in logs:
        cur.execute(
            """
            INSERT INTO audit_logs
                   (user_id, action_type, entity_name, entity_id, description)
            VALUES (%s, %s, %s, %s, %s)
            """,
            (user_id, action, entity, entity_id, desc),
        )
    log(f"  📝  Audit logs {len(logs)} inserted", quiet)


# ─────────────────────────────────────────────────────────────────────────────
# RESET
# ─────────────────────────────────────────────────────────────────────────────

def reset_all(cur, quiet):
    tables = [
        "audit_logs", "notifications", "request_approvals",
        "stock_transactions", "request_items", "requests",
        "inventory_batches", "vendor_products", "products",
        "vendors", "categories", "users",
    ]
    for t in tables:
        cur.execute(f"TRUNCATE TABLE {t} RESTART IDENTITY CASCADE")
    log("  🗑️   All tables truncated (RESTART IDENTITY CASCADE)", quiet)


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Seed KitchenLedger database with mock data")
    parser.add_argument("--reset", action="store_true", help="Wipe all data before seeding")
    parser.add_argument("--quiet", action="store_true", help="Suppress row-level output")
    args = parser.parse_args()

    print("\n🌱  KitchenLedger Database Seeder")
    print("=" * 50)

    # Boot DB
    init_pool()
    create_tables()
    run_migrations()

    conn = get_connection()
    cur  = conn.cursor()
    # Use RealDictCursor so all fetches return dicts
    from psycopg2.extras import RealDictCursor
    cur = conn.cursor(cursor_factory=RealDictCursor)

    try:
        if args.reset:
            print("\n⚠️   --reset flag detected. Wiping existing data...")
            reset_all(cur, args.quiet)

        print("\n👤  Users")
        user_ids = seed_users(cur, args.quiet)

        print("\n🏷️   Categories")
        cat_ids = seed_categories(cur, args.quiet)

        print("\n🏪  Vendors")
        ven_ids = seed_vendors(cur, args.quiet)

        print("\n📦  Products")
        prod_ids = seed_products(cur, cat_ids, args.quiet)

        print("\n🔗  Vendor ↔ Product links")
        seed_vendor_products(cur, ven_ids, prod_ids, args.quiet)

        print("\n📥  Inventory Batches  (+ PURCHASE transactions)")
        seed_batches(cur, ven_ids, prod_ids, user_ids, args.quiet)

        print("\n📋  Requests")
        req_ids = seed_requests(cur, prod_ids, user_ids, args.quiet)

        print("\n🔔  Notifications")
        seed_notifications(cur, user_ids, req_ids, args.quiet)

        print("\n📝  Audit Logs")
        seed_audit_logs(cur, user_ids, args.quiet)

        conn.commit()

        print("\n" + "=" * 50)
        print("✅  Seeding complete!\n")
        print("  Test credentials:")
        print("  ┌─────────────────────────────────────────────┐")
        print("  │  Role   │ Email                │ Password    │")
        print("  ├─────────┼──────────────────────┼─────────────┤")
        print("  │  store  │ rahul@kitchen.com    │ Store@1234  │")
        print("  │  store  │ priya@kitchen.com    │ Store@1234  │")
        print("  │  chef   │ arjun@kitchen.com    │ Chef@1234   │")
        print("  │  chef   │ sneha@kitchen.com    │ Chef@1234   │")
        print("  └─────────┴──────────────────────┴─────────────┘")
        print()

    except Exception as e:
        conn.rollback()
        print(f"\n❌  Seeding failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        cur.close()
        conn.close()


if __name__ == "__main__":
    main()
