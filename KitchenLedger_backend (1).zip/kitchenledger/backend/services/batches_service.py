"""
Inventory Batches service.
Security: parameterised queries throughout.
Business logic: quantity_available initialised = quantity on creation.
"""
from typing import Optional
from datetime import date
from fastapi import HTTPException
from backend.connection.db_connection import get_cursor
import backend.services.notifications_service as notif_svc


def list_batches(
    product_id: Optional[int],
    vendor_id: Optional[int],
    expiring_within: Optional[int],
    page: int,
    limit: int,
) -> dict:
    limit  = min(max(limit, 1), 100)
    offset = (page - 1) * limit

    conditions = ["1=1"]
    params: list = []

    if product_id:
        conditions.append("b.product_id = %s")
        params.append(product_id)
    if vendor_id:
        conditions.append("b.vendor_id = %s")
        params.append(vendor_id)
    if expiring_within is not None:
        conditions.append(
            "b.expiry_date IS NOT NULL AND b.expiry_date <= CURRENT_DATE + %s::int"
        )
        params.append(expiring_within)

    where = " AND ".join(conditions)

    with get_cursor() as cur:
        cur.execute(
            f"""
            SELECT b.id, b.product_id, p.name AS product_name,
                   b.vendor_id, v.name AS vendor_name,
                   b.quantity, b.quantity_available,
                   b.unit_cost, b.total_cost,
                   b.purchase_date, b.expiry_date, b.created_at,
                   COUNT(*) OVER() AS total_count
            FROM   inventory_batches b
            JOIN   products p ON p.id = b.product_id
            LEFT   JOIN vendors v ON v.id = b.vendor_id
            WHERE  {where}
            ORDER  BY b.purchase_date ASC, b.id ASC
            LIMIT  %s OFFSET %s
            """,
            params + [limit, offset],
        )
        rows = cur.fetchall()

    total = int(rows[0]["total_count"]) if rows else 0
    data  = [_clean(r) for r in rows]
    return {"data": data, "total": total, "page": page, "limit": limit}


def get_batch(product_id: int) -> dict:
    """Return all batches for a product (path param named product_id per CSV row 16)."""
    with get_cursor() as cur:
        cur.execute(
            """
            SELECT b.id, b.product_id, p.name AS product_name,
                   b.vendor_id, v.name AS vendor_name,
                   b.quantity, b.quantity_available,
                   b.unit_cost, b.total_cost,
                   b.purchase_date, b.expiry_date, b.created_at
            FROM   inventory_batches b
            JOIN   products p ON p.id = b.product_id
            LEFT   JOIN vendors v ON v.id = b.vendor_id
            WHERE  b.product_id = %s
            ORDER  BY b.purchase_date ASC, b.id ASC
            """,
            (product_id,),
        )
        rows = cur.fetchall()
    if not rows:
        raise HTTPException(status_code=404, detail="No batches found for this product")
    return {"data": [dict(r) for r in rows]}


def create_batch(data: dict, user_id: int) -> dict:
    product_id    = data["product_id"]
    vendor_id     = data["vendor_id"]
    quantity      = data["quantity"]
    unit_cost     = data.get("unit_cost")
    purchase_date = data.get("purchase_date") or date.today()
    expiry_date   = data.get("expiry_date")

    if expiry_date and expiry_date < purchase_date:
        raise HTTPException(
            status_code=422, detail="expiry_date must be after purchase_date"
        )

    with get_cursor(commit=True) as cur:
        # Validate foreign keys
        cur.execute(
            "SELECT id FROM products WHERE id = %s AND is_active = TRUE", (product_id,)
        )
        if not cur.fetchone():
            raise HTTPException(status_code=400, detail="Product not found")

        cur.execute(
            "SELECT id FROM vendors WHERE id = %s AND is_active = TRUE", (vendor_id,)
        )
        if not cur.fetchone():
            raise HTTPException(status_code=400, detail="Vendor not found")

        cur.execute(
            """
            INSERT INTO inventory_batches
                   (product_id, vendor_id, quantity, quantity_available,
                    unit_cost, purchase_date, expiry_date)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            RETURNING id, product_id, vendor_id, quantity, quantity_available,
                      unit_cost, total_cost, purchase_date, expiry_date, created_at
            """,
            (
                product_id, vendor_id, quantity, quantity,
                unit_cost, purchase_date, expiry_date,
            ),
        )
        row = dict(cur.fetchone())

        # Upsert vendor_product link
        cur.execute(
            """
            INSERT INTO vendor_products (vendor_id, product_id, unit_cost, is_active)
            VALUES (%s, %s, %s, TRUE)
            ON CONFLICT (vendor_id, product_id)
            DO UPDATE SET unit_cost = EXCLUDED.unit_cost, is_active = TRUE
            """,
            (vendor_id, product_id, unit_cost),
        )

        # Create PURCHASE stock_transaction
        cur.execute(
            """
            INSERT INTO stock_transactions
                   (batch_id, product_id, transaction_type, quantity, performed_by)
            VALUES (%s, %s, 'PURCHASE', %s, %s)
            """,
            (row["id"], product_id, quantity, user_id),
        )

        _audit(cur, user_id, "CREATE", "inventory_batches", row["id"],
               f"Stock purchase: product_id={product_id}, qty={quantity}")

        # Notify all chefs about new stock
        notif_svc.push_to_role(
            cur, "chef",
            title="New Stock Received",
            message=f"A new batch of {quantity} units was added for product ID {product_id}.",
            entity_type="inventory_batches",
            entity_id=row["id"],
        )

    row["product_name"] = None
    row["vendor_name"]  = None
    return row


def create_batch_bulk(items: list, user_id: int) -> list:
    return [create_batch(item, user_id) for item in items]


def expiry_alerts(days: int) -> dict:
    days = max(1, min(days, 365))
    with get_cursor() as cur:
        cur.execute(
            """
            SELECT b.id, p.name AS product_name,
                   b.quantity_available, b.expiry_date,
                   (b.expiry_date - CURRENT_DATE) AS days_left,
                   CASE
                     WHEN b.expiry_date < CURRENT_DATE THEN 'expired'
                     ELSE 'expiring_soon'
                   END AS status
            FROM   inventory_batches b
            JOIN   products p ON p.id = b.product_id
            WHERE  b.expiry_date IS NOT NULL
              AND  b.quantity_available > 0
              AND  b.expiry_date <= CURRENT_DATE + %s::int
            ORDER  BY b.expiry_date ASC
            """,
            (days,),
        )
        rows = [dict(r) for r in cur.fetchall()]
    return {"products": rows}


# ── helpers ──────────────────────────────────────────────────────────────────

def _clean(row) -> dict:
    d = dict(row)
    d.pop("total_count", None)
    return d


def _audit(cur, user_id, action, entity, entity_id, description):
    cur.execute(
        """
        INSERT INTO audit_logs
               (user_id, action_type, entity_name, entity_id, description)
        VALUES (%s, %s, %s, %s, %s)
        """,
        (user_id, action, entity, entity_id, description),
    )
