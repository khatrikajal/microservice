"""
Categories service.
Security: 100 % parameterised queries — no string interpolation of user data.
"""
from fastapi import HTTPException
from backend.connection.db_connection import get_cursor


def list_categories() -> dict:
    with get_cursor() as cur:
        cur.execute("""
            SELECT id, name, is_active,
                   COALESCE(is_custom, FALSE) AS is_custom
            FROM   categories
            WHERE  is_active = TRUE
            ORDER  BY name
        """)
        rows = [dict(r) for r in cur.fetchall()]

    defaults = [r for r in rows if not r["is_custom"]]
    custom   = [r for r in rows if r["is_custom"]]
    return {"defaults": defaults, "custom": custom, "all": rows}


def create_category(name: str, user_id: int) -> dict:
    with get_cursor(commit=True) as cur:
        cur.execute(
            "SELECT id FROM categories WHERE LOWER(name) = LOWER(%s)",
            (name,),
        )
        if cur.fetchone():
            raise HTTPException(status_code=409, detail="Category name already exists")

        cur.execute(
            """
            INSERT INTO categories (name, is_custom, is_active)
            VALUES (%s, TRUE, TRUE)
            RETURNING id, name, is_active, is_custom
            """,
            (name,),
        )
        row = dict(cur.fetchone())

        _audit(cur, user_id, "CREATE", "categories", row["id"],
               f"Created category '{name}'")
        return row


def delete_category(category_id: int, user_id: int) -> dict:
    with get_cursor(commit=True) as cur:
        cur.execute(
            """
            SELECT id, name, COALESCE(is_custom, FALSE) AS is_custom
            FROM   categories
            WHERE  id = %s AND is_active = TRUE
            """,
            (category_id,),
        )
        cat = cur.fetchone()
        if not cat:
            raise HTTPException(status_code=404, detail="Category not found")
        if not cat["is_custom"]:
            raise HTTPException(status_code=403, detail="Default categories cannot be deleted")

        # Block if products reference it
        cur.execute(
            "SELECT id FROM products WHERE category_id = %s AND is_active = TRUE LIMIT 1",
            (category_id,),
        )
        if cur.fetchone():
            raise HTTPException(
                status_code=409,
                detail="Category is in use by active products and cannot be deleted",
            )

        cur.execute(
            "UPDATE categories SET is_active = FALSE WHERE id = %s",
            (category_id,),
        )
        _audit(cur, user_id, "DELETE", "categories", category_id,
               f"Deleted category '{cat['name']}'")
    return {"message": "Category deleted"}


# ── helper ───────────────────────────────────────────────────────────────────

def _audit(cur, user_id, action, entity, entity_id, description):
    cur.execute(
        """
        INSERT INTO audit_logs
               (user_id, action_type, entity_name, entity_id, description)
        VALUES (%s, %s, %s, %s, %s)
        """,
        (user_id, action, entity, entity_id, description),
    )
