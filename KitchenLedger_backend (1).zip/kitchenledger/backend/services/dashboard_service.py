"""
Dashboard service.
Role-separated card metrics and widget data.
Security: fully parameterised.
"""
from backend.connection.db_connection import get_cursor


# ── Store Manager Dashboard ───────────────────────────────────────────────────

def store_cards() -> dict:
    """Total stock value, expiring-soon count, pending requests count."""
    with get_cursor() as cur:
        cur.execute("""
            SELECT COALESCE(SUM(b.quantity_available * COALESCE(b.unit_cost, 0)), 0) AS total_stock_value,
                   COALESCE(SUM(b.quantity_available), 0) AS total_units
            FROM   inventory_batches b
        """)
        stock = cur.fetchone()

        cur.execute("""
            SELECT COUNT(*) AS cnt
            FROM   inventory_batches
            WHERE  expiry_date IS NOT NULL
              AND  quantity_available > 0
              AND  expiry_date <= CURRENT_DATE + 30
        """)
        expiring_soon = cur.fetchone()["cnt"]

        cur.execute(
            "SELECT COUNT(*) AS cnt FROM requests WHERE status = 'PENDING'"
        )
        pending_requests = cur.fetchone()["cnt"]

    return {
        "total_stock_value": float(stock["total_stock_value"]),
        "total_units":       int(stock["total_units"]),
        "expiring_soon":     int(expiring_soon),
        "pending_requests":  int(pending_requests),
    }


def store_expiry_alerts(days: int) -> dict:
    """Products expiring within `days` days, grouped by status."""
    days = max(1, min(days, 365))
    with get_cursor() as cur:
        cur.execute(
            """
            SELECT p.name AS product_name,
                   b.id   AS batch_id,
                   b.quantity_available,
                   b.expiry_date,
                   (b.expiry_date - CURRENT_DATE) AS days_left,
                   CASE
                     WHEN b.expiry_date < CURRENT_DATE THEN 'expired'
                     ELSE 'expiring_soon'
                   END AS status
            FROM   inventory_batches b
            JOIN   products p ON p.id = b.product_id
            WHERE  b.expiry_date IS NOT NULL
              AND  b.quantity_available > 0
              AND  b.expiry_date <= CURRENT_DATE + %s::int
            ORDER  BY b.expiry_date ASC
            """,
            (days,),
        )
        rows = [dict(r) for r in cur.fetchall()]
    return {"products": rows}


# ── Chef Dashboard ────────────────────────────────────────────────────────────

def chef_cards() -> dict:
    """Total / pending / approved / rejected request counts."""
    with get_cursor() as cur:
        cur.execute("""
            SELECT
                COUNT(*)                                          AS total,
                COUNT(*) FILTER (WHERE status = 'PENDING')       AS pending,
                COUNT(*) FILTER (WHERE status = 'APPROVED')      AS approved,
                COUNT(*) FILTER (WHERE status = 'REJECTED')      AS rejected,
                COUNT(*) FILTER (WHERE status = 'ISSUED')        AS issued
            FROM requests
        """)
        row = cur.fetchone()
    return {
        "total":    int(row["total"]),
        "pending":  int(row["pending"]),
        "approved": int(row["approved"]),
        "rejected": int(row["rejected"]),
        "issued":   int(row["issued"]),
    }


def chef_pending_requests(page: int, limit: int) -> dict:
    """Paginated list of PENDING requests for the chef approval queue."""
    limit  = min(max(limit, 1), 100)
    offset = (page - 1) * limit

    with get_cursor() as cur:
        cur.execute(
            """
            SELECT r.id, r.requested_by, u.name AS requester_name,
                   r.priority, r.reason, r.request_date, r.created_at,
                   COUNT(*) OVER() AS total_count
            FROM   requests r
            LEFT   JOIN users u ON u.id = r.requested_by
            WHERE  r.status = 'PENDING'
            ORDER  BY
                CASE r.priority
                    WHEN 'high'   THEN 1
                    WHEN 'medium' THEN 2
                    ELSE               3
                END,
                r.created_at ASC
            LIMIT  %s OFFSET %s
            """,
            (limit, offset),
        )
        rows = cur.fetchall()

        request_ids = [r["id"] for r in rows]
        items_map: dict = {}
        if request_ids:
            cur.execute(
                """
                SELECT ri.request_id, ri.id, ri.product_id,
                       p.name AS product_name, ri.requested_quantity
                FROM   request_items ri
                JOIN   products p ON p.id = ri.product_id
                WHERE  ri.request_id = ANY(%s)
                """,
                (request_ids,),
            )
            for item in cur.fetchall():
                items_map.setdefault(item["request_id"], []).append(dict(item))

    total = int(rows[0]["total_count"]) if rows else 0
    data  = []
    for r in rows:
        d          = dict(r)
        d.pop("total_count", None)
        d["items"] = items_map.get(d["id"], [])
        data.append(d)
    return {"data": data, "total": total, "page": page, "limit": limit}


def chef_low_stock() -> dict:
    """Products whose available stock is below min_stock_level."""
    with get_cursor() as cur:
        cur.execute("""
            SELECT p.name AS product_name,
                   c.name AS category,
                   p.unit,
                   p.min_stock_level,
                   COALESCE(SUM(b.quantity_available), 0) AS current_qty
            FROM   products p
            LEFT   JOIN categories c ON c.id = p.category_id
            LEFT   JOIN inventory_batches b ON b.product_id = p.id
            WHERE  p.is_active = TRUE
              AND  p.min_stock_level > 0
            GROUP  BY p.id, c.name
            HAVING COALESCE(SUM(b.quantity_available), 0) < p.min_stock_level
            ORDER  BY current_qty ASC
        """)
        rows = [dict(r) for r in cur.fetchall()]
    return {"data": rows}
