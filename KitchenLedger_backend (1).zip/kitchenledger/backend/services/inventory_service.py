"""
Inventory valuation service.
Calculates total inventory value = SUM(quantity_available × unit_cost)
broken down by category.
Security: fully parameterised.
"""
from typing import Optional
from backend.connection.db_connection import get_cursor


def valuation(category: Optional[str]) -> dict:
    conditions = ["b.quantity_available > 0", "b.unit_cost IS NOT NULL"]
    params: list = []

    if category:
        conditions.append("c.name ILIKE %s")
        params.append(f"%{category}%")

    where = " AND ".join(conditions)

    with get_cursor() as cur:
        cur.execute(
            f"""
            SELECT c.name AS category,
                   COALESCE(SUM(b.quantity_available * b.unit_cost), 0) AS value
            FROM   inventory_batches b
            JOIN   products   p ON p.id = b.product_id
            LEFT   JOIN categories c ON c.id = p.category_id
            WHERE  {where}
            GROUP  BY c.name
            ORDER  BY value DESC
            """,
            params,
        )
        by_cat = [dict(r) for r in cur.fetchall()]

        total = sum(float(r["value"]) for r in by_cat)

    return {
        "total_value": total,
        "by_category": [
            {"category": r["category"], "value": float(r["value"])}
            for r in by_cat
        ],
    }
