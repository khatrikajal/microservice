"""
Notifications service.
Called internally by other services (requests, batches) to push
in-app notifications to users.
"""
from typing import Optional
from backend.connection.db_connection import get_cursor


# ── internal helper called from other services ────────────────────────────────

def push(
    cur,                        # reuse the caller's cursor / transaction
    user_id: int,
    title: str,
    message: Optional[str] = None,
    entity_type: Optional[str] = None,
    entity_id: Optional[int] = None,
) -> None:
    """Insert a notification row inside an existing cursor transaction."""
    cur.execute(
        """
        INSERT INTO notifications
               (user_id, title, message, entity_type, entity_id)
        VALUES (%s, %s, %s, %s, %s)
        """,
        (user_id, title, message, entity_type, entity_id),
    )


def push_to_role(
    cur,
    role: str,
    title: str,
    message: Optional[str] = None,
    entity_type: Optional[str] = None,
    entity_id: Optional[int] = None,
) -> None:
    """Push a notification to every active user with the given role."""
    cur.execute(
        "SELECT id FROM users WHERE role = %s AND is_active = TRUE",
        (role,),
    )
    for row in cur.fetchall():
        push(cur, row["id"], title, message, entity_type, entity_id)


# ── public API ────────────────────────────────────────────────────────────────

def list_notifications(
    user_id: int,
    is_read: Optional[bool],
    page: int,
    limit: int,
) -> dict:
    limit  = min(max(limit, 1), 100)
    offset = (page - 1) * limit

    conditions = ["user_id = %s"]
    params: list = [user_id]

    if is_read is not None:
        conditions.append("is_read = %s")
        params.append(is_read)

    where = " AND ".join(conditions)

    with get_cursor() as cur:
        cur.execute(
            f"""
            SELECT id, user_id, title, message, is_read,
                   entity_type, entity_id, created_at,
                   COUNT(*) OVER() AS total_count
            FROM   notifications
            WHERE  {where}
            ORDER  BY created_at DESC
            LIMIT  %s OFFSET %s
            """,
            params + [limit, offset],
        )
        rows = cur.fetchall()

        cur.execute(
            "SELECT COUNT(*) AS cnt FROM notifications WHERE user_id = %s AND is_read = FALSE",
            (user_id,),
        )
        unread = cur.fetchone()["cnt"]

    total = int(rows[0]["total_count"]) if rows else 0
    data  = [_clean(r) for r in rows]
    return {"data": data, "unread_count": unread, "total": total, "page": page, "limit": limit}


def mark_read(notification_id: int, user_id: int) -> dict:
    from fastapi import HTTPException

    with get_cursor(commit=True) as cur:
        cur.execute(
            "SELECT id FROM notifications WHERE id = %s AND user_id = %s",
            (notification_id, user_id),
        )
        if not cur.fetchone():
            raise HTTPException(status_code=404, detail="Notification not found")

        cur.execute(
            "UPDATE notifications SET is_read = TRUE WHERE id = %s AND user_id = %s",
            (notification_id, user_id),
        )
    return {"message": "Marked as read"}


def mark_all_read(user_id: int) -> dict:
    with get_cursor(commit=True) as cur:
        cur.execute(
            "UPDATE notifications SET is_read = TRUE WHERE user_id = %s AND is_read = FALSE",
            (user_id,),
        )
        count = cur.rowcount
    return {"message": "All notifications marked as read", "updated_count": count}


# ── helpers ──────────────────────────────────────────────────────────────────

def _clean(row) -> dict:
    d = dict(row)
    d.pop("total_count", None)
    return d
