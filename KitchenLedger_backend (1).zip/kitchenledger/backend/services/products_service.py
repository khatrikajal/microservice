"""
Products service.
Security: parameterised queries throughout.
Dynamic UPDATE uses a hardcoded-column allowlist.
"""
from typing import Optional
from fastapi import HTTPException
from backend.connection.db_connection import get_cursor


def list_products(
    category_id: Optional[int],
    search: Optional[str],
    page: int,
    limit: int,
) -> dict:
    limit  = min(max(limit, 1), 100)
    offset = (page - 1) * limit

    conditions = ["p.is_active = TRUE"]
    params: list = []

    if category_id:
        conditions.append("p.category_id = %s")
        params.append(category_id)
    if search:
        conditions.append("p.name ILIKE %s")
        params.append(f"%{search}%")

    where = " AND ".join(conditions)

    with get_cursor() as cur:
        cur.execute(
            f"""
            SELECT p.id, p.name, p.category_id, c.name AS category_name,
                   p.brand_name, p.unit, p.shelf_life_days, p.min_stock_level,
                   p.is_active, p.created_at,
                   COALESCE(SUM(b.quantity_available), 0) AS total_stock,
                   COUNT(*) OVER() AS total_count
            FROM   products p
            LEFT   JOIN categories c ON c.id = p.category_id
            LEFT   JOIN inventory_batches b ON b.product_id = p.id
            WHERE  {where}
            GROUP  BY p.id, c.name
            ORDER  BY p.name
            LIMIT  %s OFFSET %s
            """,
            params + [limit, offset],
        )
        rows = cur.fetchall()

    total = int(rows[0]["total_count"]) if rows else 0
    data  = [_clean(r) for r in rows]
    return {"data": data, "total": total, "page": page, "limit": limit}


def get_product(product_id: int) -> dict:
    with get_cursor() as cur:
        cur.execute(
            """
            SELECT p.id, p.name, p.category_id, c.name AS category_name,
                   p.brand_name, p.unit, p.shelf_life_days, p.min_stock_level,
                   p.is_active, p.created_at,
                   COALESCE(SUM(b.quantity_available), 0) AS total_stock
            FROM   products p
            LEFT   JOIN categories c ON c.id = p.category_id
            LEFT   JOIN inventory_batches b ON b.product_id = p.id
            WHERE  p.id = %s AND p.is_active = TRUE
            GROUP  BY p.id, c.name
            """,
            (product_id,),
        )
        product = cur.fetchone()
        if not product:
            raise HTTPException(status_code=404, detail="Product not found")

        # Batch summaries
        cur.execute(
            """
            SELECT id, quantity, quantity_available, expiry_date, purchase_date
            FROM   inventory_batches
            WHERE  product_id = %s
            ORDER  BY purchase_date ASC
            """,
            (product_id,),
        )
        batches = [dict(r) for r in cur.fetchall()]

    result           = dict(product)
    result["batches"] = batches
    return result


def create_product(data: dict, user_id: int) -> dict:
    with get_cursor(commit=True) as cur:
        # Validate category exists
        cur.execute(
            "SELECT id FROM categories WHERE id = %s AND is_active = TRUE",
            (data["category_id"],),
        )
        if not cur.fetchone():
            raise HTTPException(status_code=400, detail="Category not found")

        # Unique name check
        cur.execute(
            "SELECT id FROM products WHERE LOWER(name) = LOWER(%s) AND is_active = TRUE",
            (data["name"],),
        )
        if cur.fetchone():
            raise HTTPException(status_code=409, detail="Product name already exists")

        cur.execute(
            """
            INSERT INTO products
                   (name, category_id, brand_name, unit, shelf_life_days, min_stock_level)
            VALUES (%s, %s, %s, %s, %s, %s)
            RETURNING id, name, category_id, brand_name, unit,
                      shelf_life_days, min_stock_level, is_active, created_at
            """,
            (
                data["name"], data["category_id"], data.get("brand_name"),
                data["unit"], data.get("shelf_life_days"), data.get("min_stock_level", 0),
            ),
        )
        row = dict(cur.fetchone())
        row["total_stock"]    = 0.0
        row["category_name"]  = None

        _audit(cur, user_id, "CREATE", "products", row["id"],
               f"Created product '{data['name']}'")
        return row


def update_product(product_id: int, data: dict, user_id: int) -> dict:
    # Allowed columns — never interpolate user-supplied column names
    _COLS = {
        "name": "name",
        "category_id": "category_id",
        "brand_name": "brand_name",
        "unit": "unit",
        "shelf_life_days": "shelf_life_days",
        "min_stock_level": "min_stock_level",
    }

    with get_cursor(commit=True) as cur:
        cur.execute(
            "SELECT id FROM products WHERE id = %s AND is_active = TRUE",
            (product_id,),
        )
        if not cur.fetchone():
            raise HTTPException(status_code=404, detail="Product not found")

        if data.get("category_id"):
            cur.execute(
                "SELECT id FROM categories WHERE id = %s AND is_active = TRUE",
                (data["category_id"],),
            )
            if not cur.fetchone():
                raise HTTPException(status_code=400, detail="Category not found")

        if data.get("name"):
            cur.execute(
                """
                SELECT id FROM products
                WHERE  LOWER(name) = LOWER(%s) AND id != %s AND is_active = TRUE
                """,
                (data["name"], product_id),
            )
            if cur.fetchone():
                raise HTTPException(status_code=409, detail="Product name already exists")

        set_parts: list[str] = []
        params: list         = []
        for field, col in _COLS.items():
            if data.get(field) is not None:
                set_parts.append(f"{col} = %s")
                params.append(data[field])

        if not set_parts:
            raise HTTPException(status_code=400, detail="No fields to update")

        params.append(product_id)
        cur.execute(
            f"""
            UPDATE products SET {', '.join(set_parts)} WHERE id = %s
            RETURNING id, name, category_id, brand_name, unit,
                      shelf_life_days, min_stock_level, is_active, created_at
            """,
            params,
        )
        row                  = dict(cur.fetchone())
        row["total_stock"]   = 0.0
        row["category_name"] = None

        _audit(cur, user_id, "UPDATE", "products", product_id,
               f"Updated product '{row['name']}'")
        return row


def delete_product(product_id: int, user_id: int) -> dict:
    with get_cursor(commit=True) as cur:
        cur.execute(
            "SELECT id, name FROM products WHERE id = %s AND is_active = TRUE",
            (product_id,),
        )
        product = cur.fetchone()
        if not product:
            raise HTTPException(status_code=404, detail="Product not found")

        # Block if active batches exist
        cur.execute(
            """
            SELECT id FROM inventory_batches
            WHERE  product_id = %s AND quantity_available > 0
            LIMIT  1
            """,
            (product_id,),
        )
        if cur.fetchone():
            raise HTTPException(
                status_code=409,
                detail="Product has active inventory – delete blocked",
            )

        # Block if pending requests reference it
        cur.execute(
            """
            SELECT ri.id
            FROM   request_items ri
            JOIN   requests r ON r.id = ri.request_id
            WHERE  ri.product_id = %s AND r.status = 'PENDING'
            LIMIT  1
            """,
            (product_id,),
        )
        if cur.fetchone():
            raise HTTPException(
                status_code=409,
                detail="Product has pending requests – delete blocked",
            )

        cur.execute(
            "UPDATE products SET is_active = FALSE WHERE id = %s",
            (product_id,),
        )
        _audit(cur, user_id, "DELETE", "products", product_id,
               f"Deleted product '{product['name']}'")
    return {"message": "Product deleted"}


# ── helpers ──────────────────────────────────────────────────────────────────

def _clean(row) -> dict:
    d = dict(row)
    d.pop("total_count", None)
    d["total_stock"] = float(d.get("total_stock") or 0)
    return d


def _audit(cur, user_id, action, entity, entity_id, description):
    cur.execute(
        """
        INSERT INTO audit_logs
               (user_id, action_type, entity_name, entity_id, description)
        VALUES (%s, %s, %s, %s, %s)
        """,
        (user_id, action, entity, entity_id, description),
    )
