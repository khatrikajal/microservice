"""
Reports service.
All queries are parameterised. Date filters use cast to date for safety.
"""
from typing import Optional
from datetime import date
from backend.connection.db_connection import get_cursor


# ── Dashboard KPI summary ─────────────────────────────────────────────────────

def summary(role: str) -> dict:
    with get_cursor() as cur:
        cur.execute("SELECT COUNT(*) AS cnt FROM products WHERE is_active = TRUE")
        total_products = cur.fetchone()["cnt"]

        cur.execute("""
            SELECT COALESCE(SUM(b.quantity_available * b.unit_cost), 0) AS val
            FROM   inventory_batches b
        """)
        total_stock_value = float(cur.fetchone()["val"])

        cur.execute("""
            SELECT COUNT(DISTINCT p.id) AS cnt
            FROM   products p
            WHERE  p.is_active = TRUE
              AND  p.min_stock_level > 0
              AND  (SELECT COALESCE(SUM(b.quantity_available), 0)
                    FROM   inventory_batches b
                    WHERE  b.product_id = p.id) < p.min_stock_level
        """)
        low_stock_items = cur.fetchone()["cnt"]

        cur.execute("""
            SELECT COUNT(*) AS cnt
            FROM   inventory_batches
            WHERE  expiry_date IS NOT NULL
              AND  quantity_available > 0
              AND  expiry_date <= CURRENT_DATE + 30
        """)
        expiring_soon = cur.fetchone()["cnt"]

        cur.execute(
            "SELECT COUNT(*) AS cnt FROM requests WHERE status = 'PENDING'"
        )
        pending_requests = cur.fetchone()["cnt"]

        cur.execute("""
            SELECT COUNT(*) AS cnt
            FROM   stock_transactions
            WHERE  transaction_type = 'ISSUE'
              AND  created_at::date = CURRENT_DATE
        """)
        todays_issues = cur.fetchone()["cnt"]

    return {
        "total_products":    total_products,
        "total_stock_value": total_stock_value,
        "low_stock_items":   low_stock_items,
        "expiring_soon":     expiring_soon,
        "pending_requests":  pending_requests,
        "todays_issues":     todays_issues,
    }


# ── Stock levels ──────────────────────────────────────────────────────────────

def stock_report(
    category: Optional[str],
    low_stock: Optional[bool],
    start_date: Optional[date],
    end_date: Optional[date],
) -> dict:
    conditions = ["p.is_active = TRUE"]
    params: list = []

    if category:
        conditions.append("c.name ILIKE %s")
        params.append(f"%{category}%")

    where = " AND ".join(conditions)

    with get_cursor() as cur:
        cur.execute(
            f"""
            SELECT p.id, p.name AS product_name, c.name AS category,
                   p.unit, p.min_stock_level,
                   COALESCE(SUM(b.quantity_available), 0) AS total_qty,
                   CASE
                     WHEN COALESCE(SUM(b.quantity_available), 0) = 0 THEN 'out'
                     WHEN COALESCE(SUM(b.quantity_available), 0) < p.min_stock_level THEN 'low'
                     ELSE 'ok'
                   END AS status
            FROM   products p
            LEFT   JOIN categories c ON c.id = p.category_id
            LEFT   JOIN inventory_batches b ON b.product_id = p.id
            WHERE  {where}
            GROUP  BY p.id, c.name
            ORDER  BY status, p.name
            """,
            params,
        )
        rows = [dict(r) for r in cur.fetchall()]

    if low_stock:
        rows = [r for r in rows if r["status"] in ("low", "out")]
    return {"data": rows}


# ── Vendor report ─────────────────────────────────────────────────────────────

def vendor_report(
    vendor_id: Optional[int],
    start_date: Optional[date],
    end_date: Optional[date],
) -> dict:
    conditions = ["1=1"]
    params: list = []

    if vendor_id:
        conditions.append("b.vendor_id = %s")
        params.append(vendor_id)
    if start_date:
        conditions.append("b.purchase_date >= %s")
        params.append(start_date)
    if end_date:
        conditions.append("b.purchase_date <= %s")
        params.append(end_date)

    where = " AND ".join(conditions)

    with get_cursor() as cur:
        cur.execute(
            f"""
            SELECT v.id, v.name AS vendor_name,
                   COUNT(b.id) AS total_purchases,
                   COALESCE(SUM(b.total_cost), 0) AS total_value,
                   ARRAY_AGG(DISTINCT p.name) AS items_supplied
            FROM   inventory_batches b
            JOIN   vendors  v ON v.id = b.vendor_id
            JOIN   products p ON p.id = b.product_id
            WHERE  {where}
            GROUP  BY v.id, v.name
            ORDER  BY total_value DESC
            """,
            params,
        )
        rows = [dict(r) for r in cur.fetchall()]
    return {"data": rows}


# ── Category report ───────────────────────────────────────────────────────────

def category_report(start_date: Optional[date], end_date: Optional[date]) -> dict:
    date_filter = ""
    params: list = []

    if start_date:
        date_filter += " AND st.created_at::date >= %s"
        params.append(start_date)
    if end_date:
        date_filter += " AND st.created_at::date <= %s"
        params.append(end_date)

    with get_cursor() as cur:
        cur.execute(
            f"""
            SELECT c.name AS category,
                   COALESCE(SUM(b.quantity_available), 0) AS total_stock,
                   COALESCE(SUM(CASE WHEN st.transaction_type = 'ISSUE' THEN st.quantity ELSE 0 END), 0)
                       AS consumed_qty,
                   COUNT(DISTINCT r.id) AS request_count
            FROM   categories c
            LEFT   JOIN products p ON p.category_id = c.id AND p.is_active = TRUE
            LEFT   JOIN inventory_batches b ON b.product_id = p.id
            LEFT   JOIN stock_transactions st ON st.product_id = p.id {date_filter}
            LEFT   JOIN request_items ri ON ri.product_id = p.id
            LEFT   JOIN requests r ON r.id = ri.request_id
            WHERE  c.is_active = TRUE
            GROUP  BY c.name
            ORDER  BY c.name
            """,
            params,
        )
        rows = [dict(r) for r in cur.fetchall()]
    return {"data": rows}


# ── Consumption trend ─────────────────────────────────────────────────────────

def consumption_report(
    product_id: Optional[int],
    group_by: str,
    start_date: Optional[date],
    end_date: Optional[date],
) -> dict:
    if group_by not in ("day", "week", "month"):
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail="groupBy must be day, week, or month")

    trunc_map = {"day": "day", "week": "week", "month": "month"}
    trunc     = trunc_map[group_by]   # safe – validated above

    conditions = ["st.transaction_type = 'ISSUE'"]
    params: list = []

    if product_id:
        conditions.append("st.product_id = %s")
        params.append(product_id)
    if start_date:
        conditions.append("st.created_at::date >= %s")
        params.append(start_date)
    if end_date:
        conditions.append("st.created_at::date <= %s")
        params.append(end_date)

    where = " AND ".join(conditions)

    with get_cursor() as cur:
        cur.execute(
            f"""
            SELECT DATE_TRUNC(%s, st.created_at)::date AS period,
                   p.name AS product_name,
                   SUM(st.quantity) AS quantity_issued
            FROM   stock_transactions st
            JOIN   products p ON p.id = st.product_id
            WHERE  {where}
            GROUP  BY period, p.name
            ORDER  BY period ASC, p.name
            """,
            [trunc] + params,
        )
        rows = [dict(r) for r in cur.fetchall()]
    return {"data": rows}


# ── Expiry report ─────────────────────────────────────────────────────────────

def expiry_report(status: Optional[str], days: int) -> dict:
    days = max(1, min(days, 365))

    if status and status not in ("expired", "expiring"):
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail="status must be 'expired' or 'expiring'")

    extra = ""
    if status == "expired":
        extra = "AND b.expiry_date < CURRENT_DATE"
    elif status == "expiring":
        extra = "AND b.expiry_date >= CURRENT_DATE"

    with get_cursor() as cur:
        cur.execute(
            f"""
            SELECT p.name AS product_name, b.id AS batch_id,
                   b.quantity_available AS quantity,
                   b.expiry_date,
                   (b.expiry_date - CURRENT_DATE) AS days_left
            FROM   inventory_batches b
            JOIN   products p ON p.id = b.product_id
            WHERE  b.expiry_date IS NOT NULL
              AND  b.quantity_available > 0
              AND  b.expiry_date <= CURRENT_DATE + %s::int
              {extra}
            ORDER  BY b.expiry_date ASC
            """,
            (days,),
        )
        rows = [dict(r) for r in cur.fetchall()]
    return {"data": rows}


# ── Card metrics ──────────────────────────────────────────────────────────────

def card_report() -> dict:
    with get_cursor() as cur:
        cur.execute("""
            SELECT COALESCE(SUM(st.quantity), 0) AS qty_used
            FROM   stock_transactions st
            WHERE  st.transaction_type = 'ISSUE'
        """)
        qty_used = float(cur.fetchone()["qty_used"])

        cur.execute("""
            SELECT COALESCE(SUM(b.unit_cost * b.quantity), 0) AS purchase_cost
            FROM   inventory_batches b
        """)
        purchase_cost = float(cur.fetchone()["purchase_cost"])

        # Wastage = expired stock value
        cur.execute("""
            SELECT COALESCE(SUM(b.quantity_available * b.unit_cost), 0) AS wastage
            FROM   inventory_batches b
            WHERE  b.expiry_date IS NOT NULL
              AND  b.expiry_date < CURRENT_DATE
              AND  b.quantity_available > 0
        """)
        wastage_cost = float(cur.fetchone()["wastage"])

    return {
        "qty_used":      qty_used,
        "wastage_cost":  wastage_cost,
        "purchase_cost": purchase_cost,
    }
