"""
Requests service.
Critical path:
  • Request creation  → store role only, pending status
  • Chef approval     → FIFO batch deduction with SELECT ... FOR UPDATE
                        to prevent race conditions / double-deduction
  • All queries       → 100 % parameterised (no injection risk)
  • Audit logged      → every state change
"""
from typing import Optional
from datetime import date
from fastapi import HTTPException
from backend.connection.db_connection import get_cursor
import backend.services.notifications_service as notif_svc


# ─────────────────────────────────────────────────────────────────────────────
# LIST
# ─────────────────────────────────────────────────────────────────────────────

def list_requests(
    current_user: dict,
    status: Optional[str],
    product_id: Optional[int],
    start_date: Optional[date],
    end_date: Optional[date],
    page: int,
    limit: int,
) -> dict:
    limit  = min(max(limit, 1), 100)
    offset = (page - 1) * limit

    conditions = ["1=1"]
    params: list = []

    # Store managers see only their own; chefs see all
    if current_user["role"] == "store":
        conditions.append("r.requested_by = %s")
        params.append(current_user["id"])

    if status:
        _validate_status(status)
        conditions.append("r.status = %s")
        params.append(status)
    if product_id:
        conditions.append(
            "EXISTS (SELECT 1 FROM request_items ri2 WHERE ri2.request_id = r.id AND ri2.product_id = %s)"
        )
        params.append(product_id)
    if start_date:
        conditions.append("r.request_date >= %s")
        params.append(start_date)
    if end_date:
        conditions.append("r.request_date <= %s")
        params.append(end_date)

    where = " AND ".join(conditions)

    with get_cursor() as cur:
        cur.execute(
            f"""
            SELECT r.id, r.requested_by, u.name AS requester_name,
                   r.status, r.priority, r.reason, r.request_date, r.created_at,
                   COUNT(*) OVER() AS total_count
            FROM   requests r
            LEFT   JOIN users u ON u.id = r.requested_by
            WHERE  {where}
            ORDER  BY r.created_at DESC
            LIMIT  %s OFFSET %s
            """,
            params + [limit, offset],
        )
        rows = cur.fetchall()
        request_ids = [r["id"] for r in rows]
        items_map   = _fetch_items(cur, request_ids) if request_ids else {}

    total = int(rows[0]["total_count"]) if rows else 0
    data  = []
    for r in rows:
        d          = dict(r)
        d.pop("total_count", None)
        d["items"] = items_map.get(d["id"], [])
        data.append(d)
    return {"data": data, "total": total, "page": page, "limit": limit}


# ─────────────────────────────────────────────────────────────────────────────
# GET ONE
# ─────────────────────────────────────────────────────────────────────────────

def get_request(request_id: int, current_user: dict) -> dict:
    with get_cursor() as cur:
        cur.execute(
            """
            SELECT r.id, r.requested_by, u.name AS requester_name,
                   r.status, r.priority, r.reason, r.request_date, r.created_at
            FROM   requests r
            LEFT   JOIN users u ON u.id = r.requested_by
            WHERE  r.id = %s
            """,
            (request_id,),
        )
        row = cur.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Request not found")

        # Store can only view their own
        if current_user["role"] == "store" and row["requested_by"] != current_user["id"]:
            raise HTTPException(status_code=403, detail="Access denied")

        items_map      = _fetch_items(cur, [request_id])
        result         = dict(row)
        result["items"] = items_map.get(request_id, [])
    return result


# ─────────────────────────────────────────────────────────────────────────────
# CREATE
# ─────────────────────────────────────────────────────────────────────────────

def create_request(data: dict, user_id: int) -> dict:
    items        = data["items"]
    reason       = data.get("reason")
    priority     = data.get("priority", "medium")
    request_date = data.get("request_date") or date.today()

    with get_cursor(commit=True) as cur:
        # Validate all products exist
        for item in items:
            cur.execute(
                "SELECT id FROM products WHERE id = %s AND is_active = TRUE",
                (item["product_id"],),
            )
            if not cur.fetchone():
                raise HTTPException(
                    status_code=400,
                    detail=f"Product id={item['product_id']} not found",
                )

        cur.execute(
            """
            INSERT INTO requests (requested_by, status, priority, reason, request_date)
            VALUES (%s, 'PENDING', %s, %s, %s)
            RETURNING id, requested_by, status, priority, reason, request_date, created_at
            """,
            (user_id, priority, reason, request_date),
        )
        req = dict(cur.fetchone())

        created_items = []
        for item in items:
            cur.execute(
                """
                INSERT INTO request_items
                       (request_id, product_id, requested_quantity)
                VALUES (%s, %s, %s)
                RETURNING id, product_id, requested_quantity, approved_quantity, fulfilled_quantity
                """,
                (req["id"], item["product_id"], item["requested_quantity"]),
            )
            created_items.append(dict(cur.fetchone()))

        _audit(cur, user_id, "CREATE", "requests", req["id"],
               f"Created request with {len(items)} item(s)")

        # Notify all chefs
        notif_svc.push_to_role(
            cur, "chef",
            title="New Stock Request",
            message=f"A new stock request (ID {req['id']}) has been submitted.",
            entity_type="requests",
            entity_id=req["id"],
        )

    req["items"]          = created_items
    req["requester_name"] = None
    return req


# ─────────────────────────────────────────────────────────────────────────────
# PATCH – store edits / chef approves
# ─────────────────────────────────────────────────────────────────────────────

def patch_request(request_id: int, data: dict, current_user: dict) -> dict:
    role    = current_user["role"]
    user_id = current_user["id"]

    with get_cursor(commit=True) as cur:
        cur.execute(
            "SELECT id, status, requested_by FROM requests WHERE id = %s",
            (request_id,),
        )
        req = cur.fetchone()
        if not req:
            raise HTTPException(status_code=404, detail="Request not found")

        if role == "store":
            return _store_edit(cur, req, data, user_id)
        else:
            return _chef_action(cur, req, data, user_id)


def _store_edit(cur, req, data: dict, user_id: int) -> dict:
    if req["status"] != "PENDING":
        raise HTTPException(status_code=409, detail="Only pending requests can be edited")
    if req["requested_by"] != user_id:
        raise HTTPException(status_code=403, detail="Can only edit your own requests")

    updates = []
    params  = []
    if data.get("reason") is not None:
        updates.append("reason = %s")
        params.append(data["reason"])
    if data.get("priority") is not None:
        updates.append("priority = %s")
        params.append(data["priority"])

    if updates:
        params.append(req["id"])
        cur.execute(
            f"UPDATE requests SET {', '.join(updates)} WHERE id = %s",
            params,
        )
        _audit(cur, user_id, "UPDATE", "requests", req["id"], "Store edited pending request")

    return _fetch_full(cur, req["id"])


def _chef_action(cur, req, data: dict, user_id: int) -> dict:
    if req["status"] != "PENDING":
        raise HTTPException(status_code=409, detail="Request is not pending")

    approval_status = data["approval_status"]
    remarks         = data.get("remarks")
    item_approvals  = {ia["request_item_id"]: ia["approved_quantity"]
                       for ia in (data.get("item_approvals") or [])}

    # Fetch items
    cur.execute(
        """
        SELECT id, product_id, requested_quantity
        FROM   request_items
        WHERE  request_id = %s
        """,
        (req["id"],),
    )
    items = cur.fetchall()

    new_status = "APPROVED" if approval_status in ("APPROVED", "MODIFIED") else "REJECTED"

    if new_status == "APPROVED":
        for item in items:
            approved_qty = item_approvals.get(item["id"], item["requested_quantity"])
            if approved_qty > 0:
                actual = _fifo_deduct(
                    cur,
                    product_id=item["product_id"],
                    quantity=approved_qty,
                    request_item_id=item["id"],
                    performed_by=user_id,
                )
            else:
                actual = 0

            cur.execute(
                """
                UPDATE request_items
                SET    approved_quantity  = %s,
                       fulfilled_quantity = %s
                WHERE  id = %s
                """,
                (approved_qty, actual, item["id"]),
            )

    # Update request status
    cur.execute(
        "UPDATE requests SET status = %s WHERE id = %s",
        (new_status, req["id"]),
    )

    # Record approval
    cur.execute(
        """
        INSERT INTO request_approvals
               (request_id, approved_by, approval_status, remarks)
        VALUES (%s, %s, %s, %s)
        """,
        (req["id"], user_id, approval_status, remarks),
    )

    _audit(cur, user_id, "UPDATE", "requests", req["id"],
           f"Chef set status={new_status}")

    # Notify requester
    if req["requested_by"]:
        notif_svc.push(
            cur, req["requested_by"],
            title=f"Request {new_status}",
            message=f"Your request (ID {req['id']}) was {new_status.lower()}."
                    + (f" Remarks: {remarks}" if remarks else ""),
            entity_type="requests",
            entity_id=req["id"],
        )

    return _fetch_full(cur, req["id"])


# ─────────────────────────────────────────────────────────────────────────────
# DELETE (cancel)
# ─────────────────────────────────────────────────────────────────────────────

def cancel_request(request_id: int, user_id: int) -> dict:
    with get_cursor(commit=True) as cur:
        cur.execute(
            "SELECT id, status, requested_by FROM requests WHERE id = %s",
            (request_id,),
        )
        req = cur.fetchone()
        if not req:
            raise HTTPException(status_code=404, detail="Request not found")
        if req["requested_by"] != user_id:
            raise HTTPException(status_code=403, detail="Cannot cancel another user's request")
        if req["status"] != "PENDING":
            raise HTTPException(status_code=403, detail="Only pending requests can be recalled")

        cur.execute("DELETE FROM requests WHERE id = %s", (request_id,))
        _audit(cur, user_id, "DELETE", "requests", request_id, "Store recalled pending request")
    return {"message": "Request recalled"}


# ─────────────────────────────────────────────────────────────────────────────
# PENDING COUNT
# ─────────────────────────────────────────────────────────────────────────────

def pending_count() -> dict:
    with get_cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) AS cnt FROM requests WHERE status = 'PENDING'"
        )
        return {"pending_count": cur.fetchone()["cnt"]}


# ─────────────────────────────────────────────────────────────────────────────
# FIFO deduction (SELECT ... FOR UPDATE prevents race conditions)
# ─────────────────────────────────────────────────────────────────────────────

def _fifo_deduct(cur, product_id: int, quantity: int,
                 request_item_id: int, performed_by: int) -> int:
    """
    Deducts `quantity` from inventory batches using FIFO order.
    Locks rows with FOR UPDATE to prevent concurrent double-deductions.
    Returns the actual quantity deducted.
    """
    cur.execute(
        """
        SELECT id, quantity_available
        FROM   inventory_batches
        WHERE  product_id = %s AND quantity_available > 0
        ORDER  BY purchase_date ASC, id ASC
        FOR    UPDATE
        """,
        (product_id,),
    )
    batches   = cur.fetchall()
    remaining = quantity

    for batch in batches:
        if remaining <= 0:
            break
        deduct = min(remaining, batch["quantity_available"])

        cur.execute(
            """
            UPDATE inventory_batches
            SET    quantity_available = quantity_available - %s
            WHERE  id = %s
            """,
            (deduct, batch["id"]),
        )
        cur.execute(
            """
            INSERT INTO stock_transactions
                   (batch_id, product_id, request_item_id,
                    transaction_type, quantity, performed_by)
            VALUES (%s, %s, %s, 'ISSUE', %s, %s)
            """,
            (batch["id"], product_id, request_item_id, deduct, performed_by),
        )
        remaining -= deduct

    return quantity - remaining  # actual amount deducted


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _fetch_items(cur, request_ids: list) -> dict:
    cur.execute(
        """
        SELECT ri.id, ri.request_id, ri.product_id, p.name AS product_name,
               ri.requested_quantity, ri.approved_quantity, ri.fulfilled_quantity
        FROM   request_items ri
        JOIN   products p ON p.id = ri.product_id
        WHERE  ri.request_id = ANY(%s)
        """,
        (request_ids,),
    )
    result: dict = {}
    for row in cur.fetchall():
        result.setdefault(row["request_id"], []).append(dict(row))
    return result


def _fetch_full(cur, request_id: int) -> dict:
    cur.execute(
        """
        SELECT r.id, r.requested_by, u.name AS requester_name,
               r.status, r.priority, r.reason, r.request_date, r.created_at
        FROM   requests r
        LEFT   JOIN users u ON u.id = r.requested_by
        WHERE  r.id = %s
        """,
        (request_id,),
    )
    row            = dict(cur.fetchone())
    items_map      = _fetch_items(cur, [request_id])
    row["items"]   = items_map.get(request_id, [])
    return row


def _validate_status(status: str) -> None:
    allowed = {"PENDING", "APPROVED", "REJECTED", "ISSUED"}
    if status.upper() not in allowed:
        raise HTTPException(status_code=400, detail=f"Invalid status. Allowed: {allowed}")


def _audit(cur, user_id, action, entity, entity_id, description):
    cur.execute(
        """
        INSERT INTO audit_logs
               (user_id, action_type, entity_name, entity_id, description)
        VALUES (%s, %s, %s, %s, %s)
        """,
        (user_id, action, entity, entity_id, description),
    )
