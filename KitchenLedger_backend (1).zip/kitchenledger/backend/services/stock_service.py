"""
Stock Transactions service.
Read-only audit trail of all PURCHASE and ISSUE events.
Security: fully parameterised.
"""
from typing import Optional
from datetime import date
from backend.connection.db_connection import get_cursor


def list_transactions(
    tx_type: Optional[str],
    product_id: Optional[int],
    start_date: Optional[date],
    end_date: Optional[date],
    page: int,
    limit: int,
) -> dict:
    limit  = min(max(limit, 1), 100)
    offset = (page - 1) * limit

    conditions = ["1=1"]
    params: list = []

    if tx_type:
        _type = tx_type.upper()
        if _type not in ("ISSUE", "PURCHASE"):
            from fastapi import HTTPException
            raise HTTPException(status_code=400, detail="type must be 'issue' or 'purchase'")
        conditions.append("st.transaction_type = %s")
        params.append(_type)
    if product_id:
        conditions.append("st.product_id = %s")
        params.append(product_id)
    if start_date:
        conditions.append("st.created_at::date >= %s")
        params.append(start_date)
    if end_date:
        conditions.append("st.created_at::date <= %s")
        params.append(end_date)

    where = " AND ".join(conditions)

    with get_cursor() as cur:
        cur.execute(
            f"""
            SELECT st.id, st.batch_id, st.product_id,
                   p.name AS product_name,
                   st.request_item_id, st.transaction_type,
                   st.quantity, st.performed_by,
                   u.name AS performed_by_name,
                   st.created_at,
                   COUNT(*) OVER() AS total_count
            FROM   stock_transactions st
            JOIN   products p ON p.id = st.product_id
            LEFT   JOIN users u ON u.id = st.performed_by
            WHERE  {where}
            ORDER  BY st.created_at DESC
            LIMIT  %s OFFSET %s
            """,
            params + [limit, offset],
        )
        rows = cur.fetchall()

    total = int(rows[0]["total_count"]) if rows else 0
    data  = [_clean(r) for r in rows]
    return {"data": data, "total": total, "page": page, "limit": limit}


def _clean(row) -> dict:
    d = dict(row)
    d.pop("total_count", None)
    return d
