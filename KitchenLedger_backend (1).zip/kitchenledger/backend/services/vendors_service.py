"""
Vendors service.
Security: 100 % parameterised queries.
Dynamic UPDATE builds the SET clause from a hardcoded-column allowlist;
user values are always in the params tuple — never interpolated into SQL.
"""
from typing import Optional
from fastapi import HTTPException
from backend.connection.db_connection import get_cursor

# Only these columns may be updated. Prevents column-injection if schema
# is ever extended and a bug accidentally exposed the raw field name.
_UPDATABLE = {"name", "contact", "address"}


def list_vendors(search: Optional[str], page: int, limit: int) -> dict:
    limit  = min(max(limit, 1), 100)
    offset = (page - 1) * limit

    with get_cursor() as cur:
        if search:
            cur.execute(
                """
                SELECT id, name, contact, address, is_active, created_at,
                       COUNT(*) OVER() AS total_count
                FROM   vendors
                WHERE  is_active = TRUE
                  AND  name ILIKE %s
                ORDER  BY name
                LIMIT  %s OFFSET %s
                """,
                (f"%{search}%", limit, offset),
            )
        else:
            cur.execute(
                """
                SELECT id, name, contact, address, is_active, created_at,
                       COUNT(*) OVER() AS total_count
                FROM   vendors
                WHERE  is_active = TRUE
                ORDER  BY name
                LIMIT  %s OFFSET %s
                """,
                (limit, offset),
            )
        rows = cur.fetchall()

    total = int(rows[0]["total_count"]) if rows else 0
    data  = [_strip(r) for r in rows]
    return {"data": data, "total": total, "page": page, "limit": limit}


def get_vendor(vendor_id: int) -> dict:
    with get_cursor() as cur:
        cur.execute(
            """
            SELECT id, name, contact, address, is_active, created_at
            FROM   vendors
            WHERE  id = %s AND is_active = TRUE
            """,
            (vendor_id,),
        )
        vendor = cur.fetchone()
        if not vendor:
            raise HTTPException(status_code=404, detail="Vendor not found")

        # Supplied categories (derived from vendor_products join)
        cur.execute(
            """
            SELECT DISTINCT c.name
            FROM   vendor_products vp
            JOIN   products   p ON p.id = vp.product_id
            JOIN   categories c ON c.id = p.category_id
            WHERE  vp.vendor_id = %s AND vp.is_active = TRUE
            """,
            (vendor_id,),
        )
        supplied = [r["name"] for r in cur.fetchall()]

    result                 = dict(vendor)
    result["supplied_items"] = supplied
    return result


def create_vendor(data: dict, user_id: int) -> dict:
    name          = data["name"]
    contact       = data.get("contact")
    address       = data.get("address")
    supplied_items = data.get("supplied_items", [])

    with get_cursor(commit=True) as cur:
        cur.execute(
            "SELECT id FROM vendors WHERE LOWER(name) = LOWER(%s) AND is_active = TRUE",
            (name,),
        )
        if cur.fetchone():
            raise HTTPException(status_code=409, detail="Vendor name already exists")

        cur.execute(
            """
            INSERT INTO vendors (name, contact, address)
            VALUES (%s, %s, %s)
            RETURNING id, name, contact, address, is_active, created_at
            """,
            (name, contact, address),
        )
        row = dict(cur.fetchone())
        _audit(cur, user_id, "CREATE", "vendors", row["id"],
               f"Created vendor '{name}'")

    row["supplied_items"] = supplied_items
    return row


def update_vendor(vendor_id: int, data: dict, user_id: int) -> dict:
    with get_cursor(commit=True) as cur:
        cur.execute(
            "SELECT id, name FROM vendors WHERE id = %s AND is_active = TRUE",
            (vendor_id,),
        )
        if not cur.fetchone():
            raise HTTPException(status_code=404, detail="Vendor not found")

        # Build SET clause from the allowlist only
        set_parts: list[str] = []
        params: list         = []

        if data.get("name") is not None:
            cur.execute(
                """
                SELECT id FROM vendors
                WHERE LOWER(name) = LOWER(%s) AND id != %s AND is_active = TRUE
                """,
                (data["name"], vendor_id),
            )
            if cur.fetchone():
                raise HTTPException(status_code=409, detail="Vendor name already exists")
            set_parts.append("name = %s")
            params.append(data["name"])

        for col in ("contact", "address"):
            if data.get(col) is not None:
                set_parts.append(f"{col} = %s")   # col is from our hardcoded list
                params.append(data[col])

        if set_parts:
            params.append(vendor_id)
            cur.execute(
                f"UPDATE vendors SET {', '.join(set_parts)} WHERE id = %s "
                "RETURNING id, name, contact, address, is_active, created_at",
                params,
            )
            row = dict(cur.fetchone())
        else:
            cur.execute(
                "SELECT id, name, contact, address, is_active, created_at "
                "FROM vendors WHERE id = %s",
                (vendor_id,),
            )
            row = dict(cur.fetchone())

        _audit(cur, user_id, "UPDATE", "vendors", vendor_id,
               f"Updated vendor '{row['name']}'")

    row["supplied_items"] = data.get("supplied_items") or []
    return row


def delete_vendor(vendor_id: int, user_id: int) -> dict:
    with get_cursor(commit=True) as cur:
        cur.execute(
            "SELECT id, name FROM vendors WHERE id = %s AND is_active = TRUE",
            (vendor_id,),
        )
        vendor = cur.fetchone()
        if not vendor:
            raise HTTPException(status_code=404, detail="Vendor not found")

        cur.execute(
            """
            SELECT id FROM inventory_batches
            WHERE  vendor_id = %s AND quantity_available > 0
            LIMIT  1
            """,
            (vendor_id,),
        )
        if cur.fetchone():
            raise HTTPException(
                status_code=409,
                detail="Vendor has active inventory batches – soft-delete blocked",
            )

        cur.execute(
            "UPDATE vendors SET is_active = FALSE WHERE id = %s",
            (vendor_id,),
        )
        _audit(cur, user_id, "DELETE", "vendors", vendor_id,
               f"Deleted vendor '{vendor['name']}'")
    return {"message": "Vendor deleted"}


# ── helpers ──────────────────────────────────────────────────────────────────

def _strip(row) -> dict:
    d = dict(row)
    d.pop("total_count", None)
    d["supplied_items"] = []
    return d


def _audit(cur, user_id, action, entity, entity_id, description):
    cur.execute(
        """
        INSERT INTO audit_logs
               (user_id, action_type, entity_name, entity_id, description)
        VALUES (%s, %s, %s, %s, %s)
        """,
        (user_id, action, entity, entity_id, description),
    )
