from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from backend.auth.utils import decode_access_token
from backend.connection.db_connection import get_connection

bearer_scheme = HTTPBearer()


def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)):
    token   = credentials.credentials
    payload = decode_access_token(token)

    if not payload:
        raise HTTPException(
            status_code = status.HTTP_401_UNAUTHORIZED,
            detail      = "Invalid or expired token.",
            headers     = {"WWW-Authenticate": "Bearer"},
        )

    user_id = int(payload.get("sub"))
    role    = payload.get("role")

    conn   = get_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            SELECT id, name, email, role, is_active
            FROM   users
            WHERE  id = %s
        """, (user_id,))

        row = cursor.fetchone()

        if not row:
            raise HTTPException(status_code=401, detail="User not found.")

        uid, name, email, db_role, is_active = row

        if not is_active:
            raise HTTPException(status_code=403, detail="Account is deactivated.")

        return {"id": uid, "name": name, "email": email, "role": db_role}

    finally:
        cursor.close()
        conn.close()


def require_role(*roles: str):
    """Usage: Depends(require_role('admin', 'store_manager'))"""
    def role_checker(current_user: dict = Depends(get_current_user)):
        if current_user["role"] not in roles:
            raise HTTPException(
                status_code = status.HTTP_403_FORBIDDEN,
                detail      = f"Access denied. Required roles: {', '.join(roles)}"
            )
        return current_user
    return role_checker
