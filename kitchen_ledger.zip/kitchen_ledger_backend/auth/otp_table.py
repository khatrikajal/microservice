from backend.connection.db_connection import get_connection


def create_otp_table():
    conn = get_connection()
    cursor = conn.cursor()

    # OTP purpose:
    #   'signup'         — verify email before account creation
    #   'reset_password' — verify email before password reset

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS otp_verifications (
        id          SERIAL PRIMARY KEY,
        email       VARCHAR(100) NOT NULL,
        otp         VARCHAR(6)   NOT NULL,
        purpose     VARCHAR(20)  NOT NULL,
        is_used     BOOLEAN      DEFAULT FALSE,
        expires_at  TIMESTAMP    NOT NULL,
        created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
    );
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_otp_email_purpose
        ON otp_verifications(email, purpose);
    """)

    conn.commit()
    cursor.close()
    conn.close()
