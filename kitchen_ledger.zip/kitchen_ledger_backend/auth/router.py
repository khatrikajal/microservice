from fastapi import APIRouter, Depends

from backend.auth import service
from backend.auth.dependencies import get_current_user
from backend.auth.schemas import (
    ForgotPasswordSchema,
    LoginSchema,
    MessageResponseSchema,
    ResetPasswordSchema,
    SignupRequestSchema,
    SignupVerifySchema,
    TokenResponseSchema,
)

router = APIRouter(prefix="/auth", tags=["Authentication"])

# Temporary store for signup data between Step 1 and Step 2.
# In production replace with Redis or a pending_signups DB table.
_pending_signups: dict = {}


# ──────────────────────────────────────────────────────────────────────────────
# SIGNUP — Step 1: Request OTP
# ──────────────────────────────────────────────────────────────────────────────

@router.post(
    "/signup/request",
    response_model = MessageResponseSchema,
    summary        = "Send OTP to email for signup verification",
)
def signup_request(body: SignupRequestSchema):
    result = service.signup_request(
        name    = body.name,
        email   = body.email,
        password= body.password,
        role    = body.role,
        contact = body.contact,
    )
    # Temporarily hold signup data until OTP is verified
    _pending_signups[body.email] = {
        "name":     body.name,
        "password": body.password,
        "role":     body.role,
        "contact":  body.contact,
    }
    return result


# ──────────────────────────────────────────────────────────────────────────────
# SIGNUP — Step 2: Verify OTP and Create Account
# ──────────────────────────────────────────────────────────────────────────────

@router.post(
    "/signup/verify",
    response_model = MessageResponseSchema,
    summary        = "Verify OTP and complete account creation",
)
def signup_verify(body: SignupVerifySchema):
    pending = _pending_signups.get(body.email)

    if not pending:
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail="No pending signup for this email. Please start signup again.")

    result = service.signup_verify(
        name    = pending["name"],
        email   = body.email,
        password= pending["password"],
        role    = pending["role"],
        contact = pending["contact"],
        otp     = body.otp,
    )

    # Clean up pending signup data
    _pending_signups.pop(body.email, None)
    return result


# ──────────────────────────────────────────────────────────────────────────────
# LOGIN
# ──────────────────────────────────────────────────────────────────────────────

@router.post(
    "/login",
    response_model = TokenResponseSchema,
    summary        = "Login and get access token",
)
def login(body: LoginSchema):
    return service.login(email=body.email, password=body.password)


# ──────────────────────────────────────────────────────────────────────────────
# FORGOT PASSWORD
# ──────────────────────────────────────────────────────────────────────────────

@router.post(
    "/forgot-password",
    response_model = MessageResponseSchema,
    summary        = "Send OTP to email for password reset",
)
def forgot_password(body: ForgotPasswordSchema):
    return service.forgot_password(email=body.email)


# ──────────────────────────────────────────────────────────────────────────────
# RESET PASSWORD
# ──────────────────────────────────────────────────────────────────────────────

@router.post(
    "/reset-password",
    response_model = MessageResponseSchema,
    summary        = "Verify OTP and set new password",
)
def reset_password(body: ResetPasswordSchema):
    return service.reset_password(
        email        = body.email,
        otp          = body.otp,
        new_password = body.new_password,
    )


# ──────────────────────────────────────────────────────────────────────────────
# ME — Get current logged-in user
# ──────────────────────────────────────────────────────────────────────────────

@router.get(
    "/me",
    summary = "Get current logged-in user info",
)
def get_me(current_user: dict = Depends(get_current_user)):
    return current_user
