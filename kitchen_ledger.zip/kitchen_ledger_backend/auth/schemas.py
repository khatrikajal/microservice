from pydantic import BaseModel, EmailStr
from typing import Optional


# ──────────────────────────────────────────
# SIGNUP
# ──────────────────────────────────────────

class SignupRequestSchema(BaseModel):
    """Step 1 — Send OTP to email"""
    name:     str
    email:    EmailStr
    password: str
    role:     str
    contact:  Optional[str] = None


class SignupVerifySchema(BaseModel):
    """Step 2 — Verify OTP and create account"""
    email: EmailStr
    otp:   str


# ──────────────────────────────────────────
# LOGIN
# ──────────────────────────────────────────

class LoginSchema(BaseModel):
    email:    EmailStr
    password: str


class TokenResponseSchema(BaseModel):
    access_token: str
    token_type:   str = "bearer"
    user_id:      int
    name:         str
    role:         str


# ──────────────────────────────────────────
# FORGOT / RESET PASSWORD
# ──────────────────────────────────────────

class ForgotPasswordSchema(BaseModel):
    email: EmailStr


class ResetPasswordSchema(BaseModel):
    email:        EmailStr
    otp:          str
    new_password: str


# ──────────────────────────────────────────
# GENERIC RESPONSE
# ──────────────────────────────────────────

class MessageResponseSchema(BaseModel):
    message: str
