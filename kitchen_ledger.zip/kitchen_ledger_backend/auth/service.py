from datetime import datetime

from fastapi import HTTPException, status

from backend.connection.db_connection import get_connection
from backend.auth.utils import (
    hash_password,
    verify_password,
    create_access_token,
    generate_otp,
    otp_expiry,
    send_email,
    signup_otp_email,
    reset_password_otp_email,
)


# ──────────────────────────────────────────────────────────────────────────────
# HELPER — OTP
# ──────────────────────────────────────────────────────────────────────────────

def _save_otp(cursor, email: str, otp: str, purpose: str) -> None:
    """Invalidate any previous unused OTPs for this email+purpose, then save new one."""
    cursor.execute("""
        UPDATE otp_verifications
        SET    is_used = TRUE
        WHERE  email   = %s
          AND  purpose = %s
          AND  is_used = FALSE
    """, (email, purpose))

    cursor.execute("""
        INSERT INTO otp_verifications (email, otp, purpose, expires_at)
        VALUES (%s, %s, %s, %s)
    """, (email, otp, purpose, otp_expiry()))


def _verify_otp(cursor, email: str, otp: str, purpose: str) -> None:
    """
    Validate OTP. Raises HTTPException on:
    - OTP not found
    - Already used
    - Expired
    - Wrong code
    """
    cursor.execute("""
        SELECT id, otp, is_used, expires_at
        FROM   otp_verifications
        WHERE  email   = %s
          AND  purpose = %s
        ORDER  BY created_at DESC
        LIMIT  1
    """, (email, purpose))

    row = cursor.fetchone()

    if not row:
        raise HTTPException(status_code=400, detail="OTP not found. Please request a new one.")

    otp_id, saved_otp, is_used, expires_at = row

    if is_used:
        raise HTTPException(status_code=400, detail="OTP already used. Please request a new one.")

    if datetime.utcnow() > expires_at:
        raise HTTPException(status_code=400, detail="OTP has expired. Please request a new one.")

    if otp != saved_otp:
        raise HTTPException(status_code=400, detail="Invalid OTP.")

    # Mark OTP as used
    cursor.execute("UPDATE otp_verifications SET is_used = TRUE WHERE id = %s", (otp_id,))


# ──────────────────────────────────────────────────────────────────────────────
# SIGNUP — STEP 1: Send OTP
# ──────────────────────────────────────────────────────────────────────────────

def signup_request(name: str, email: str, password: str, role: str, contact: str | None):
    conn   = get_connection()
    cursor = conn.cursor()

    try:
        # Check if email already registered
        cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
        if cursor.fetchone():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email is already registered."
            )

        otp = generate_otp()
        _save_otp(cursor, email, otp, purpose="signup")
        conn.commit()

        # Send OTP email
        send_email(
            to_email  = email,
            subject   = "Kitchen Ledger — Email Verification OTP",
            html_body = signup_otp_email(name, otp),
        )

        return {"message": f"OTP sent to {email}. Please verify to complete signup."}

    except HTTPException:
        conn.rollback()
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to send OTP: {str(e)}")
    finally:
        cursor.close()
        conn.close()


# ──────────────────────────────────────────────────────────────────────────────
# SIGNUP — STEP 2: Verify OTP and Create User
# ──────────────────────────────────────────────────────────────────────────────

def signup_verify(name: str, email: str, password: str, role: str, contact: str | None, otp: str):
    conn   = get_connection()
    cursor = conn.cursor()

    try:
        # Re-check email not already registered
        cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
        if cursor.fetchone():
            raise HTTPException(status_code=400, detail="Email is already registered.")

        # Validate OTP
        _verify_otp(cursor, email, otp, purpose="signup")

        # Create user
        password_hash = hash_password(password)
        cursor.execute("""
            INSERT INTO users (name, email, role, password_hash, contact)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING id, name, role
        """, (name, email, role, password_hash, contact))

        user_id, user_name, user_role = cursor.fetchone()
        conn.commit()

        return {"message": "Account created successfully. You can now login."}

    except HTTPException:
        conn.rollback()
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Signup failed: {str(e)}")
    finally:
        cursor.close()
        conn.close()


# ──────────────────────────────────────────────────────────────────────────────
# LOGIN
# ──────────────────────────────────────────────────────────────────────────────

def login(email: str, password: str):
    conn   = get_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            SELECT id, name, role, password_hash, is_active
            FROM   users
            WHERE  email = %s
        """, (email,))

        row = cursor.fetchone()

        if not row:
            raise HTTPException(status_code=401, detail="Invalid email or password.")

        user_id, name, role, password_hash, is_active = row

        if not is_active:
            raise HTTPException(status_code=403, detail="Your account has been deactivated.")

        if not verify_password(password, password_hash):
            raise HTTPException(status_code=401, detail="Invalid email or password.")

        token = create_access_token(data={"sub": str(user_id), "role": role})

        return {
            "access_token": token,
            "token_type":   "bearer",
            "user_id":      user_id,
            "name":         name,
            "role":         role,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Login failed: {str(e)}")
    finally:
        cursor.close()
        conn.close()


# ──────────────────────────────────────────────────────────────────────────────
# FORGOT PASSWORD — Send OTP
# ──────────────────────────────────────────────────────────────────────────────

def forgot_password(email: str):
    conn   = get_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT id FROM users WHERE email = %s AND is_active = TRUE", (email,))
        if not cursor.fetchone():
            # Generic message to avoid user enumeration
            return {"message": "If this email is registered, an OTP has been sent."}

        otp = generate_otp()
        _save_otp(cursor, email, otp, purpose="reset_password")
        conn.commit()

        send_email(
            to_email  = email,
            subject   = "Kitchen Ledger — Password Reset OTP",
            html_body = reset_password_otp_email(otp),
        )

        return {"message": "If this email is registered, an OTP has been sent."}

    except HTTPException:
        conn.rollback()
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to send OTP: {str(e)}")
    finally:
        cursor.close()
        conn.close()


# ──────────────────────────────────────────────────────────────────────────────
# RESET PASSWORD — Verify OTP and Update Password
# ──────────────────────────────────────────────────────────────────────────────

def reset_password(email: str, otp: str, new_password: str):
    conn   = get_connection()
    cursor = conn.cursor()

    try:
        # Validate OTP
        _verify_otp(cursor, email, otp, purpose="reset_password")

        # Update password
        new_hash = hash_password(new_password)
        cursor.execute("""
            UPDATE users
            SET    password_hash = %s
            WHERE  email = %s
        """, (new_hash, email))

        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="User not found.")

        conn.commit()

        return {"message": "Password reset successfully. You can now login with your new password."}

    except HTTPException:
        conn.rollback()
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Password reset failed: {str(e)}")
    finally:
        cursor.close()
        conn.close()
