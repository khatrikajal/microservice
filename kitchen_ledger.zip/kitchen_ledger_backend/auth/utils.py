import random
import smtplib
import string
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from jose import JWTError, jwt
from passlib.context import CryptContext

from backend.config import settings

# ──────────────────────────────────────────
# PASSWORD HASHING
# ──────────────────────────────────────────

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


# ──────────────────────────────────────────
# JWT
# ──────────────────────────────────────────

def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_access_token(token: str) -> dict | None:
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        return payload
    except JWTError:
        return None


# ──────────────────────────────────────────
# OTP GENERATION
# ──────────────────────────────────────────

def generate_otp(length: int = 6) -> str:
    return "".join(random.choices(string.digits, k=length))


def otp_expiry() -> datetime:
    return datetime.utcnow() + timedelta(minutes=settings.OTP_EXPIRE_MINUTES)


# ──────────────────────────────────────────
# EMAIL SENDING
# ──────────────────────────────────────────

def send_email(to_email: str, subject: str, html_body: str) -> None:
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = settings.DEFAULT_FROM_EMAIL
    msg["To"]      = to_email

    msg.attach(MIMEText(html_body, "html"))

    with smtplib.SMTP(settings.EMAIL_HOST, settings.EMAIL_PORT) as server:
        server.ehlo()
        if settings.EMAIL_USE_TLS:
            server.starttls()
        server.login(settings.EMAIL_HOST_USER, settings.EMAIL_HOST_PASSWORD)
        server.sendmail(settings.DEFAULT_FROM_EMAIL, to_email, msg.as_string())


# ──────────────────────────────────────────
# EMAIL TEMPLATES
# ──────────────────────────────────────────

def signup_otp_email(name: str, otp: str) -> str:
    return f"""
    <div style="font-family: Arial, sans-serif; max-width: 480px; margin: auto;
                border: 1px solid #e0e0e0; border-radius: 8px; padding: 32px;">
        <h2 style="color: #2d2d2d;">Welcome to Kitchen Ledger 👋</h2>
        <p style="color: #555;">Hi <strong>{name}</strong>,</p>
        <p style="color: #555;">Use the OTP below to verify your email and complete signup.</p>
        <div style="text-align: center; margin: 28px 0;">
            <span style="font-size: 36px; font-weight: bold; letter-spacing: 10px;
                         color: #4f46e5; background: #eef2ff; padding: 12px 24px;
                         border-radius: 8px;">{otp}</span>
        </div>
        <p style="color: #888; font-size: 13px;">
            This OTP expires in <strong>{settings.OTP_EXPIRE_MINUTES} minutes</strong>.
            Do not share it with anyone.
        </p>
    </div>
    """


def reset_password_otp_email(otp: str) -> str:
    return f"""
    <div style="font-family: Arial, sans-serif; max-width: 480px; margin: auto;
                border: 1px solid #e0e0e0; border-radius: 8px; padding: 32px;">
        <h2 style="color: #2d2d2d;">Password Reset Request 🔐</h2>
        <p style="color: #555;">Use the OTP below to reset your password.</p>
        <div style="text-align: center; margin: 28px 0;">
            <span style="font-size: 36px; font-weight: bold; letter-spacing: 10px;
                         color: #dc2626; background: #fef2f2; padding: 12px 24px;
                         border-radius: 8px;">{otp}</span>
        </div>
        <p style="color: #888; font-size: 13px;">
            This OTP expires in <strong>{settings.OTP_EXPIRE_MINUTES} minutes</strong>.
            If you did not request this, ignore this email.
        </p>
    </div>
    """
