from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import Optional
from backend.categories import service
from backend.auth.dependencies import get_current_user, require_role

router = APIRouter(prefix="/categories", tags=["Categories"])


class CategorySchema(BaseModel):
    name: str


@router.get("/", summary="List all categories")
def list_categories(is_active: Optional[bool] = None, _=Depends(get_current_user)):
    return service.get_all_categories(is_active)


@router.post("/", summary="Create category (Admin / Store Manager)")
def create_category(body: CategorySchema, _=Depends(require_role("admin", "store_manager"))):
    return service.create_category(body.name)


@router.put("/{category_id}", summary="Update category")
def update_category(
    category_id: int,
    body: CategorySchema,
    _=Depends(require_role("admin", "store_manager"))
):
    return service.update_category(category_id, body.name)


@router.patch("/{category_id}/deactivate", summary="Deactivate category")
def deactivate_category(category_id: int, _=Depends(require_role("admin", "store_manager"))):
    return service.deactivate_category(category_id)
