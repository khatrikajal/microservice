from fastapi import HTTPException
from backend.connection.db_connection import get_connection


def get_all_categories(is_active=None):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        q = "SELECT id, name, is_active FROM categories"
        p = []
        if is_active is not None:
            q += " WHERE is_active = %s"; p.append(is_active)
        q += " ORDER BY name"
        cursor.execute(q, p)
        return [{"id": r[0], "name": r[1], "is_active": r[2]} for r in cursor.fetchall()]
    finally:
        cursor.close(); conn.close()


def create_category(name: str):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id FROM categories WHERE name = %s", (name,))
        if cursor.fetchone():
            raise HTTPException(status_code=400, detail="Category already exists.")
        cursor.execute("INSERT INTO categories (name) VALUES (%s) RETURNING id", (name,))
        new_id = cursor.fetchone()[0]
        conn.commit()
        return {"message": "Category created.", "id": new_id}
    except HTTPException:
        conn.rollback(); raise
    finally:
        cursor.close(); conn.close()


def update_category(category_id: int, name: str):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("UPDATE categories SET name = %s WHERE id = %s", (name, category_id))
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Category not found.")
        conn.commit()
        return {"message": "Category updated."}
    except HTTPException:
        conn.rollback(); raise
    finally:
        cursor.close(); conn.close()


def deactivate_category(category_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("UPDATE categories SET is_active = FALSE WHERE id = %s", (category_id,))
        conn.commit()
        return {"message": "Category deactivated."}
    finally:
        cursor.close(); conn.close()
