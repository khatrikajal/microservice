import psycopg2
from backend.config import settings


def get_connection():
    conn = psycopg2.connect(settings.DATABASE_URL)
    return conn
