from fastapi import APIRouter, Depends
from backend.dashboard import service
from backend.auth.dependencies import get_current_user, require_role

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/store-manager", summary="Store Manager dashboard summary")
def store_manager_dashboard(_=Depends(require_role("admin", "store_manager"))):
    return service.get_store_manager_dashboard()


@router.get("/admin", summary="Admin dashboard summary")
def admin_dashboard(_=Depends(require_role("admin"))):
    return service.get_admin_dashboard()
