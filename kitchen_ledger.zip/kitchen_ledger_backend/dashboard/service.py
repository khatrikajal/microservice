from backend.connection.db_connection import get_connection


# ─────────────────────────────────────────────────────────────────────────────
# STORE MANAGER DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────

def get_store_manager_dashboard():
    conn = get_connection()
    cursor = conn.cursor()
    try:
        # Total distinct active products in stock
        cursor.execute("""
            SELECT COUNT(DISTINCT product_id)
            FROM   inventory_batches
            WHERE  quantity_available > 0
        """)
        total_stocked_products = cursor.fetchone()[0]

        # Total stock value (quantity_available summed across all batches)
        cursor.execute("""
            SELECT COALESCE(SUM(quantity_available), 0)
            FROM   inventory_batches
        """)
        total_units_available = cursor.fetchone()[0]

        # Low stock products (below min_stock_level)
        cursor.execute("""
            SELECT COUNT(*)
            FROM (
                SELECT p.id
                FROM   products p
                LEFT JOIN inventory_batches ib ON ib.product_id = p.id
                WHERE  p.is_active = TRUE
                GROUP  BY p.id, p.min_stock_level
                HAVING COALESCE(SUM(ib.quantity_available), 0) < p.min_stock_level
            ) sub
        """)
        low_stock_count = cursor.fetchone()[0]

        # Expiring within 7 days
        cursor.execute("""
            SELECT COUNT(*)
            FROM   inventory_batches
            WHERE  expiry_date IS NOT NULL
              AND  quantity_available > 0
              AND  expiry_date <= CURRENT_DATE + INTERVAL '7 days'
        """)
        expiring_7_days = cursor.fetchone()[0]

        # Expiring within 30 days
        cursor.execute("""
            SELECT COUNT(*)
            FROM   inventory_batches
            WHERE  expiry_date IS NOT NULL
              AND  quantity_available > 0
              AND  expiry_date <= CURRENT_DATE + INTERVAL '30 days'
        """)
        expiring_30_days = cursor.fetchone()[0]

        # Pending requests count
        cursor.execute("SELECT COUNT(*) FROM requests WHERE status = 'PENDING'")
        pending_requests = cursor.fetchone()[0]

        # Recent 5 stock issues
        cursor.execute("""
            SELECT st.id, p.name AS product_name, st.quantity,
                   st.transaction_type, st.created_at, u.name AS performed_by
            FROM   stock_transactions st
            JOIN   products p ON p.id = st.product_id
            LEFT JOIN users u ON u.id = st.performed_by
            WHERE  st.transaction_type = 'ISSUE'
            ORDER  BY st.created_at DESC
            LIMIT  5
        """)
        keys = ["id", "product_name", "quantity", "type", "date", "performed_by"]
        recent_issues = [dict(zip(keys, r)) for r in cursor.fetchall()]

        # Low stock product list (top 5)
        cursor.execute("""
            SELECT p.name, p.unit, p.min_stock_level,
                   COALESCE(SUM(ib.quantity_available), 0) AS current_stock
            FROM   products p
            LEFT JOIN inventory_batches ib ON ib.product_id = p.id
            WHERE  p.is_active = TRUE
            GROUP  BY p.name, p.unit, p.min_stock_level
            HAVING COALESCE(SUM(ib.quantity_available), 0) < p.min_stock_level
            ORDER  BY current_stock ASC
            LIMIT  5
        """)
        lkeys = ["name", "unit", "min_stock_level", "current_stock"]
        low_stock_items = [dict(zip(lkeys, r)) for r in cursor.fetchall()]

        return {
            "total_stocked_products": total_stocked_products,
            "total_units_available":  total_units_available,
            "low_stock_count":        low_stock_count,
            "expiring_7_days":        expiring_7_days,
            "expiring_30_days":       expiring_30_days,
            "pending_requests":       pending_requests,
            "recent_issues":          recent_issues,
            "low_stock_items":        low_stock_items,
        }
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────────────────────────────────────────
# ADMIN DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────

def get_admin_dashboard():
    conn = get_connection()
    cursor = conn.cursor()
    try:
        # Pending approvals
        cursor.execute("SELECT COUNT(*) FROM requests WHERE status = 'PENDING'")
        pending_approvals = cursor.fetchone()[0]

        # Total requests today
        cursor.execute("SELECT COUNT(*) FROM requests WHERE request_date = CURRENT_DATE")
        requests_today = cursor.fetchone()[0]

        # Total issued today (stock transactions)
        cursor.execute("""
            SELECT COUNT(*) FROM stock_transactions
            WHERE transaction_type = 'ISSUE'
              AND DATE(created_at) = CURRENT_DATE
        """)
        issues_today = cursor.fetchone()[0]

        # Total purchased today
        cursor.execute("""
            SELECT COUNT(*) FROM stock_transactions
            WHERE transaction_type = 'PURCHASE'
              AND DATE(created_at) = CURRENT_DATE
        """)
        purchases_today = cursor.fetchone()[0]

        # Request status breakdown
        cursor.execute("""
            SELECT status, COUNT(*) FROM requests
            GROUP  BY status
        """)
        status_breakdown = {r[0]: r[1] for r in cursor.fetchall()}

        # Top 5 most consumed products (all time)
        cursor.execute("""
            SELECT p.name, p.unit, SUM(st.quantity) AS total_issued
            FROM   stock_transactions st
            JOIN   products p ON p.id = st.product_id
            WHERE  st.transaction_type = 'ISSUE'
            GROUP  BY p.name, p.unit
            ORDER  BY total_issued DESC
            LIMIT  5
        """)
        tkeys = ["product_name", "unit", "total_issued"]
        top_consumed = [dict(zip(tkeys, r)) for r in cursor.fetchall()]

        # Active vendors count
        cursor.execute("SELECT COUNT(*) FROM vendors WHERE is_active = TRUE")
        active_vendors = cursor.fetchone()[0]

        # Total active products
        cursor.execute("SELECT COUNT(*) FROM products WHERE is_active = TRUE")
        active_products = cursor.fetchone()[0]

        # Recent pending requests (top 5) for quick approval
        cursor.execute("""
            SELECT r.id, u.name AS requested_by, r.priority,
                   r.reason, r.created_at,
                   COUNT(ri.id) AS item_count
            FROM   requests r
            LEFT JOIN users u         ON u.id  = r.requested_by
            LEFT JOIN request_items ri ON ri.request_id = r.id
            WHERE  r.status = 'PENDING'
            GROUP  BY r.id, u.name, r.priority, r.reason, r.created_at
            ORDER  BY r.created_at ASC
            LIMIT  5
        """)
        pkeys = ["id", "requested_by", "priority", "reason", "created_at", "item_count"]
        pending_list = [dict(zip(pkeys, r)) for r in cursor.fetchall()]

        # Daily consumption last 7 days
        cursor.execute("""
            SELECT DATE(created_at) AS day, SUM(quantity) AS total_units
            FROM   stock_transactions
            WHERE  transaction_type = 'ISSUE'
              AND  created_at >= CURRENT_DATE - INTERVAL '7 days'
            GROUP  BY day
            ORDER  BY day ASC
        """)
        daily_consumption = [{"date": str(r[0]), "units": r[1]} for r in cursor.fetchall()]

        return {
            "pending_approvals":   pending_approvals,
            "requests_today":      requests_today,
            "issues_today":        issues_today,
            "purchases_today":     purchases_today,
            "status_breakdown":    status_breakdown,
            "top_consumed":        top_consumed,
            "active_vendors":      active_vendors,
            "active_products":     active_products,
            "pending_list":        pending_list,
            "daily_consumption":   daily_consumption,
        }
    finally:
        cursor.close(); conn.close()
