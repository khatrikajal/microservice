from fastapi import APIRouter, Depends
from typing import Optional
from backend.inventory import service
from backend.inventory.schemas import PurchaseCreateSchema
from backend.auth.dependencies import get_current_user, require_role

router = APIRouter(prefix="/inventory", tags=["Inventory"])


@router.get("/batches", summary="List all inventory batches")
def list_batches(
    product_id:     Optional[int]  = None,
    only_available: bool           = False,
    _=Depends(get_current_user)
):
    return service.get_all_batches(product_id, only_available)


@router.get("/stock", summary="Stock summary per product")
def stock_summary(product_id: Optional[int] = None, _=Depends(get_current_user)):
    return service.get_stock_summary(product_id)


@router.get("/expiring", summary="Batches expiring within N days (default 30)")
def expiring_batches(within_days: int = 30, _=Depends(get_current_user)):
    return service.get_expiring_batches(within_days)


@router.post("/purchase", summary="Record stock purchase — creates new batch")
def add_purchase(
    body: PurchaseCreateSchema,
    current_user=Depends(require_role("admin", "store_manager"))
):
    return service.add_purchase(
        product_id   = body.product_id,
        vendor_id    = body.vendor_id,
        quantity     = body.quantity,
        expiry_date  = body.expiry_date,
        performed_by = current_user["id"],
    )


@router.post("/run-expiry-alerts", summary="Manually trigger expiry alert check (Admin)")
def run_expiry_alerts(_=Depends(require_role("admin"))):
    return service.run_expiry_alerts()
