from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime


class PurchaseCreateSchema(BaseModel):
    """Add a new stock purchase batch."""
    product_id:  int
    vendor_id:   Optional[int]  = None
    quantity:    int
    expiry_date: Optional[date] = None


class BatchResponseSchema(BaseModel):
    id:                 int
    product_id:         int
    product_name:       str
    vendor_id:          Optional[int]
    vendor_name:        Optional[str]
    quantity:           int
    quantity_available: int
    purchase_date:      date
    expiry_date:        Optional[date]
    alert_threshold:    Optional[int]
    alert_sent_at:      Optional[datetime]
    created_at:         datetime
