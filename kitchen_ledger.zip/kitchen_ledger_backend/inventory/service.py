from datetime import datetime
from fastapi import HTTPException
from backend.connection.db_connection import get_connection

BATCH_KEYS = [
    "id", "product_id", "product_name", "vendor_id", "vendor_name",
    "quantity", "quantity_available", "purchase_date",
    "expiry_date", "alert_threshold", "alert_sent_at", "created_at"
]


def _row(r):
    return dict(zip(BATCH_KEYS, r))


def _batch_query():
    return """
        SELECT ib.id, ib.product_id, p.name AS product_name,
               ib.vendor_id, v.name AS vendor_name,
               ib.quantity, ib.quantity_available,
               ib.purchase_date, ib.expiry_date,
               ib.alert_threshold, ib.alert_sent_at, ib.created_at
        FROM   inventory_batches ib
        JOIN   products p  ON p.id = ib.product_id
        LEFT JOIN vendors v ON v.id = ib.vendor_id
    """


# ─────────────────────────────────────────
# GET ALL BATCHES
# ─────────────────────────────────────────

def get_all_batches(product_id: int = None, only_available: bool = False):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        q = _batch_query() + " WHERE 1=1"
        p = []
        if product_id:
            q += " AND ib.product_id = %s"; p.append(product_id)
        if only_available:
            q += " AND ib.quantity_available > 0"
        q += " ORDER BY ib.purchase_date ASC"
        cursor.execute(q, p)
        return [_row(r) for r in cursor.fetchall()]
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────
# STOCK SUMMARY PER PRODUCT
# ─────────────────────────────────────────

def get_stock_summary(product_id: int = None):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        q = """
            SELECT p.id, p.name, p.unit, p.min_stock_level,
                   COALESCE(SUM(ib.quantity_available), 0) AS total_available,
                   COUNT(ib.id) AS batch_count
            FROM   products p
            LEFT JOIN inventory_batches ib ON ib.product_id = p.id
            WHERE  p.is_active = TRUE
        """
        p = []
        if product_id:
            q += " AND p.id = %s"; p.append(product_id)
        q += " GROUP BY p.id, p.name, p.unit, p.min_stock_level ORDER BY p.name"
        cursor.execute(q, p)
        rows = cursor.fetchall()
        keys = ["product_id", "product_name", "unit", "min_stock_level", "total_available", "batch_count"]
        return [dict(zip(keys, r)) for r in rows]
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────
# ADD PURCHASE (new batch)
# ─────────────────────────────────────────

def add_purchase(product_id, vendor_id, quantity, expiry_date, performed_by):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        # Validate product
        cursor.execute("SELECT id FROM products WHERE id = %s AND is_active = TRUE", (product_id,))
        if not cursor.fetchone():
            raise HTTPException(status_code=404, detail="Product not found or inactive.")

        # Validate vendor if provided
        if vendor_id:
            cursor.execute("SELECT id FROM vendors WHERE id = %s AND is_active = TRUE", (vendor_id,))
            if not cursor.fetchone():
                raise HTTPException(status_code=404, detail="Vendor not found or inactive.")

        cursor.execute("""
            INSERT INTO inventory_batches
                (product_id, vendor_id, quantity, quantity_available, expiry_date)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING id
        """, (product_id, vendor_id, quantity, quantity, expiry_date))
        batch_id = cursor.fetchone()[0]

        # Record PURCHASE transaction
        cursor.execute("""
            INSERT INTO stock_transactions
                (batch_id, product_id, transaction_type, quantity, performed_by)
            VALUES (%s, %s, 'PURCHASE', %s, %s)
        """, (batch_id, product_id, quantity, performed_by))

        # Audit log
        cursor.execute("""
            INSERT INTO audit_logs (user_id, action_type, entity_name, entity_id, description)
            VALUES (%s, 'PURCHASE', 'inventory_batches', %s, %s)
        """, (performed_by, batch_id, f"Purchased {quantity} units of product_id={product_id}"))

        conn.commit()
        return {"message": "Stock purchase recorded.", "batch_id": batch_id}
    except HTTPException:
        conn.rollback(); raise
    except Exception as e:
        conn.rollback(); raise HTTPException(status_code=500, detail=str(e))
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────
# EXPIRING BATCHES
# ─────────────────────────────────────────

def get_expiring_batches(within_days: int = 30):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            _batch_query() + """
            WHERE ib.expiry_date IS NOT NULL
              AND ib.quantity_available > 0
              AND ib.expiry_date <= CURRENT_DATE + INTERVAL '%s days'
            ORDER BY ib.expiry_date ASC
            """,
            (within_days,)
        )
        return [_row(r) for r in cursor.fetchall()]
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────
# EXPIRY ALERT JOB
# Call this from a scheduler (e.g. APScheduler) daily
# ─────────────────────────────────────────

def run_expiry_alerts():
    """
    Checks batches needing expiry alerts (30 days, 7 days, expired).
    Updates alert_threshold and alert_sent_at on each batch after alert fires.
    Returns list of triggered alerts for logging.
    """
    conn = get_connection()
    cursor = conn.cursor()
    triggered = []
    try:
        cursor.execute("""
            SELECT ib.id, p.name, ib.expiry_date,
                   (ib.expiry_date - CURRENT_DATE) AS days_remaining,
                   ib.alert_threshold
            FROM   inventory_batches ib
            JOIN   products p ON p.id = ib.product_id
            WHERE  ib.expiry_date IS NOT NULL
              AND  ib.quantity_available > 0
        """)
        batches = cursor.fetchall()

        for batch_id, product_name, expiry_date, days_remaining, last_threshold in batches:
            threshold = None

            if days_remaining <= 0 and (last_threshold is None or last_threshold > 0):
                threshold = 0
            elif days_remaining <= 7 and (last_threshold is None or last_threshold > 7):
                threshold = 7
            elif days_remaining <= 30 and (last_threshold is None or last_threshold > 30):
                threshold = 30

            if threshold is not None:
                cursor.execute("""
                    UPDATE inventory_batches
                    SET alert_threshold = %s, alert_sent_at = %s
                    WHERE id = %s
                """, (threshold, datetime.utcnow(), batch_id))

                triggered.append({
                    "batch_id":     batch_id,
                    "product_name": product_name,
                    "expiry_date":  str(expiry_date),
                    "days_remaining": days_remaining,
                    "alert_level":  threshold,
                })

        conn.commit()
        return {"alerts_triggered": len(triggered), "details": triggered}
    finally:
        cursor.close(); conn.close()
