from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.auth.otp_table import create_otp_table
from backend.auth.router       import router as auth_router
from backend.users.router      import router as users_router
from backend.vendors.router    import router as vendors_router
from backend.categories.router import router as categories_router
from backend.products.router   import router as products_router
from backend.inventory.router  import router as inventory_router
from backend.requests.router   import router as requests_router
from backend.dashboard.router  import router as dashboard_router
from backend.reports.router    import router as reports_router

# ─────────────────────────────────────────
# APP
# ─────────────────────────────────────────

app = FastAPI(
    title       = "Kitchen Ledger — Canteen Inventory Management",
    description = "Complete REST API for the Canteen Inventory Management System",
    version     = "1.0.0",
)

# ─────────────────────────────────────────
# CORS
# ─────────────────────────────────────────

app.add_middleware(
    CORSMiddleware,
    allow_origins     = ["http://localhost:5173", "http://localhost:3000"],
    allow_credentials = True,
    allow_methods     = ["*"],
    allow_headers     = ["*"],
)

# ─────────────────────────────────────────
# STARTUP
# ─────────────────────────────────────────

@app.on_event("startup")
def on_startup():
    create_otp_table()
    print("Kitchen Ledger API started successfully.")

# ─────────────────────────────────────────
# ROUTERS
# ─────────────────────────────────────────

app.include_router(auth_router)
app.include_router(users_router)
app.include_router(vendors_router)
app.include_router(categories_router)
app.include_router(products_router)
app.include_router(inventory_router)
app.include_router(requests_router)
app.include_router(dashboard_router)
app.include_router(reports_router)

# ─────────────────────────────────────────
# HEALTH CHECK
# ─────────────────────────────────────────

@app.get("/", tags=["Health"])
def root():
    return {"status": "ok", "message": "Kitchen Ledger API is running."}
