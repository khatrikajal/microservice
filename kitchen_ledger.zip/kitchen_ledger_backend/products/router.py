from fastapi import APIRouter, Depends
from typing import Optional
from backend.products import service
from backend.products.schemas import ProductCreateSchema, ProductUpdateSchema
from backend.auth.dependencies import get_current_user, require_role

router = APIRouter(prefix="/products", tags=["Products"])


@router.get("/", summary="List all products")
def list_products(is_active: Optional[bool] = None, _=Depends(get_current_user)):
    return service.get_all_products(is_active)


@router.get("/low-stock", summary="Products below minimum stock level")
def low_stock(_=Depends(get_current_user)):
    return service.get_low_stock_products()


@router.get("/{product_id}", summary="Get product by ID")
def get_product(product_id: int, _=Depends(get_current_user)):
    return service.get_product_by_id(product_id)


@router.post("/", summary="Create product (Admin / Store Manager)")
def create_product(body: ProductCreateSchema, _=Depends(require_role("admin", "store_manager"))):
    return service.create_product(
        body.name, body.category_id, body.unit,
        body.shelf_life_days, body.min_stock_level, body.description
    )


@router.put("/{product_id}", summary="Update product")
def update_product(
    product_id: int,
    body: ProductUpdateSchema,
    _=Depends(require_role("admin", "store_manager"))
):
    return service.update_product(
        product_id,
        name=body.name, category_id=body.category_id, unit=body.unit,
        shelf_life_days=body.shelf_life_days, min_stock_level=body.min_stock_level,
        description=body.description
    )


@router.patch("/{product_id}/deactivate", summary="Deactivate product")
def deactivate_product(product_id: int, _=Depends(require_role("admin", "store_manager"))):
    return service.deactivate_product(product_id)
