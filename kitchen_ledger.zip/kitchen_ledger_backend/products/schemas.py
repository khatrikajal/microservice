from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class ProductCreateSchema(BaseModel):
    name:            str
    category_id:     Optional[int]  = None
    unit:            Optional[str]  = None
    shelf_life_days: Optional[int]  = None
    min_stock_level: int            = 0
    description:     Optional[str]  = None


class ProductUpdateSchema(BaseModel):
    name:            Optional[str] = None
    category_id:     Optional[int] = None
    unit:            Optional[str] = None
    shelf_life_days: Optional[int] = None
    min_stock_level: Optional[int] = None
    description:     Optional[str] = None
