from fastapi import HTTPException
from backend.connection.db_connection import get_connection

KEYS = ["id", "name", "category_id", "category_name", "unit",
        "shelf_life_days", "min_stock_level", "description", "is_active", "created_at"]


def _row(r):
    return dict(zip(KEYS, r))


def get_all_products(is_active=None):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        q = """
            SELECT p.id, p.name, p.category_id, c.name AS category_name,
                   p.unit, p.shelf_life_days, p.min_stock_level,
                   p.description, p.is_active, p.created_at
            FROM   products p
            LEFT JOIN categories c ON c.id = p.category_id
        """
        p = []
        if is_active is not None:
            q += " WHERE p.is_active = %s"; p.append(is_active)
        q += " ORDER BY p.name"
        cursor.execute(q, p)
        return [_row(r) for r in cursor.fetchall()]
    finally:
        cursor.close(); conn.close()


def get_product_by_id(product_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT p.id, p.name, p.category_id, c.name,
                   p.unit, p.shelf_life_days, p.min_stock_level,
                   p.description, p.is_active, p.created_at
            FROM   products p
            LEFT JOIN categories c ON c.id = p.category_id
            WHERE  p.id = %s
        """, (product_id,))
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Product not found.")
        return _row(row)
    finally:
        cursor.close(); conn.close()


def get_low_stock_products():
    """Products where total available stock < min_stock_level."""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT p.id, p.name, c.name AS category_name, p.unit,
                   p.min_stock_level,
                   COALESCE(SUM(ib.quantity_available), 0) AS current_stock
            FROM   products p
            LEFT JOIN categories c       ON c.id  = p.category_id
            LEFT JOIN inventory_batches ib ON ib.product_id = p.id
            WHERE  p.is_active = TRUE
            GROUP  BY p.id, p.name, c.name, p.unit, p.min_stock_level
            HAVING COALESCE(SUM(ib.quantity_available), 0) < p.min_stock_level
            ORDER  BY current_stock ASC
        """)
        rows = cursor.fetchall()
        keys = ["id", "name", "category_name", "unit", "min_stock_level", "current_stock"]
        return [dict(zip(keys, r)) for r in rows]
    finally:
        cursor.close(); conn.close()


def create_product(name, category_id, unit, shelf_life_days, min_stock_level, description):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id FROM products WHERE name = %s AND is_active = TRUE", (name,))
        if cursor.fetchone():
            raise HTTPException(status_code=400, detail="Product with this name already exists.")
        cursor.execute("""
            INSERT INTO products (name, category_id, unit, shelf_life_days, min_stock_level, description)
            VALUES (%s, %s, %s, %s, %s, %s) RETURNING id
        """, (name, category_id, unit, shelf_life_days, min_stock_level, description))
        new_id = cursor.fetchone()[0]
        conn.commit()
        return {"message": "Product created.", "id": new_id}
    except HTTPException:
        conn.rollback(); raise
    except Exception as e:
        conn.rollback(); raise HTTPException(status_code=500, detail=str(e))
    finally:
        cursor.close(); conn.close()


def update_product(product_id: int, **kwargs):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        fields, params = [], []
        for k, v in kwargs.items():
            if v is not None:
                fields.append(f"{k} = %s"); params.append(v)
        if not fields:
            raise HTTPException(status_code=400, detail="No fields to update.")
        params.append(product_id)
        cursor.execute(f"UPDATE products SET {', '.join(fields)} WHERE id = %s", params)
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Product not found.")
        conn.commit()
        return {"message": "Product updated."}
    except HTTPException:
        conn.rollback(); raise
    finally:
        cursor.close(); conn.close()


def deactivate_product(product_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("UPDATE products SET is_active = FALSE WHERE id = %s", (product_id,))
        conn.commit()
        return {"message": "Product deactivated."}
    finally:
        cursor.close(); conn.close()
