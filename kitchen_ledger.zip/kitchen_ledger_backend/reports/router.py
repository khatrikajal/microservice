from fastapi import APIRouter, Depends
from datetime import date
from typing import Optional
from backend.reports import service
from backend.auth.dependencies import get_current_user, require_role

router = APIRouter(prefix="/reports", tags=["Reports"])


@router.get("/daily-stock", summary="Current stock level for all products")
def daily_stock(_=Depends(require_role("admin", "store_manager"))):
    return service.daily_stock_report()


@router.get("/consumption", summary="Item consumption in a date range")
def consumption(
    date_from: date,
    date_to:   date,
    _=Depends(require_role("admin", "store_manager"))
):
    return service.consumption_report(date_from, date_to)


@router.get("/vendor-purchases", summary="Vendor purchase history")
def vendor_purchases(
    date_from:  date,
    date_to:    date,
    vendor_id:  Optional[int] = None,
    _=Depends(require_role("admin", "store_manager"))
):
    return service.vendor_purchase_report(date_from, date_to, vendor_id)


@router.get("/expiry", summary="Expiry status report for all batches")
def expiry(_=Depends(require_role("admin", "store_manager"))):
    return service.expiry_report()


@router.get("/monthly-usage", summary="Monthly stock usage for a given year")
def monthly_usage(year: int, _=Depends(require_role("admin", "store_manager"))):
    return service.monthly_usage_report(year)


@router.get("/item-wise", summary="Full transaction history for a specific product")
def item_wise(
    product_id: int,
    date_from:  date,
    date_to:    date,
    _=Depends(require_role("admin", "store_manager"))
):
    return service.item_wise_usage_report(product_id, date_from, date_to)


@router.get("/audit-logs", summary="Audit trail report (Admin only)")
def audit_logs(
    date_from: date,
    date_to:   date,
    user_id:   Optional[int] = None,
    _=Depends(require_role("admin"))
):
    return service.audit_log_report(date_from, date_to, user_id)
