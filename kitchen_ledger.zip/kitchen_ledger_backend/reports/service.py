from datetime import date
from backend.connection.db_connection import get_connection


# ─────────────────────────────────────────────────────────────────────────────
# 1. DAILY STOCK REPORT
# Current stock level for every active product
# ─────────────────────────────────────────────────────────────────────────────

def daily_stock_report():
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT p.id, p.name, c.name AS category, p.unit, p.min_stock_level,
                   COALESCE(SUM(ib.quantity_available), 0)  AS current_stock,
                   COUNT(ib.id)                              AS batch_count,
                   MIN(ib.expiry_date)                       AS nearest_expiry
            FROM   products p
            LEFT JOIN categories c          ON c.id = p.category_id
            LEFT JOIN inventory_batches ib  ON ib.product_id = p.id
            WHERE  p.is_active = TRUE
            GROUP  BY p.id, p.name, c.name, p.unit, p.min_stock_level
            ORDER  BY p.name
        """)
        keys = ["product_id", "product_name", "category", "unit",
                "min_stock_level", "current_stock", "batch_count", "nearest_expiry"]
        rows = cursor.fetchall()
        data = []
        for r in rows:
            d = dict(zip(keys, r))
            d["nearest_expiry"] = str(d["nearest_expiry"]) if d["nearest_expiry"] else None
            d["is_low_stock"]   = d["current_stock"] < d["min_stock_level"]
            data.append(d)
        return {"report": "Daily Stock Report", "generated_at": str(date.today()), "data": data}
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────────────────────────────────────────
# 2. ITEM CONSUMPTION REPORT
# Total quantity issued per product in a date range
# ─────────────────────────────────────────────────────────────────────────────

def consumption_report(date_from: date, date_to: date):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT p.id, p.name, c.name AS category, p.unit,
                   SUM(st.quantity)     AS total_issued,
                   COUNT(st.id)         AS transaction_count
            FROM   stock_transactions st
            JOIN   products p   ON p.id  = st.product_id
            LEFT JOIN categories c ON c.id = p.category_id
            WHERE  st.transaction_type = 'ISSUE'
              AND  DATE(st.created_at) BETWEEN %s AND %s
            GROUP  BY p.id, p.name, c.name, p.unit
            ORDER  BY total_issued DESC
        """, (date_from, date_to))
        keys = ["product_id", "product_name", "category", "unit",
                "total_issued", "transaction_count"]
        data = [dict(zip(keys, r)) for r in cursor.fetchall()]
        return {
            "report": "Consumption Report",
            "from": str(date_from), "to": str(date_to),
            "data": data
        }
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────────────────────────────────────────
# 3. VENDOR PURCHASE REPORT
# All purchases grouped by vendor in a date range
# ─────────────────────────────────────────────────────────────────────────────

def vendor_purchase_report(date_from: date, date_to: date, vendor_id: int = None):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        q = """
            SELECT v.id, v.name AS vendor_name,
                   p.name AS product_name, p.unit,
                   ib.quantity, ib.purchase_date, ib.expiry_date
            FROM   inventory_batches ib
            JOIN   products p ON p.id  = ib.product_id
            LEFT JOIN vendors v   ON v.id  = ib.vendor_id
            WHERE  ib.purchase_date BETWEEN %s AND %s
        """
        params = [date_from, date_to]
        if vendor_id:
            q += " AND ib.vendor_id = %s"; params.append(vendor_id)
        q += " ORDER BY ib.purchase_date DESC, v.name"

        cursor.execute(q, params)
        keys = ["vendor_id", "vendor_name", "product_name", "unit",
                "quantity", "purchase_date", "expiry_date"]
        data = []
        for r in cursor.fetchall():
            d = dict(zip(keys, r))
            d["purchase_date"] = str(d["purchase_date"])
            d["expiry_date"]   = str(d["expiry_date"]) if d["expiry_date"] else None
            data.append(d)
        return {
            "report": "Vendor Purchase Report",
            "from": str(date_from), "to": str(date_to),
            "data": data
        }
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────────────────────────────────────────
# 4. EXPIRY REPORT
# All batches grouped by expiry status
# ─────────────────────────────────────────────────────────────────────────────

def expiry_report():
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT ib.id, p.name AS product_name, p.unit,
                   v.name AS vendor_name,
                   ib.quantity_available,
                   ib.expiry_date,
                   (ib.expiry_date - CURRENT_DATE) AS days_remaining,
                   CASE
                       WHEN ib.expiry_date < CURRENT_DATE                       THEN 'EXPIRED'
                       WHEN ib.expiry_date <= CURRENT_DATE + INTERVAL '7 days'  THEN 'CRITICAL'
                       WHEN ib.expiry_date <= CURRENT_DATE + INTERVAL '30 days' THEN 'WARNING'
                       ELSE 'OK'
                   END AS expiry_status
            FROM   inventory_batches ib
            JOIN   products p   ON p.id = ib.product_id
            LEFT JOIN vendors v ON v.id = ib.vendor_id
            WHERE  ib.expiry_date IS NOT NULL
              AND  ib.quantity_available > 0
            ORDER  BY ib.expiry_date ASC
        """)
        keys = ["batch_id", "product_name", "unit", "vendor_name",
                "quantity_available", "expiry_date", "days_remaining", "expiry_status"]
        data = []
        for r in cursor.fetchall():
            d = dict(zip(keys, r))
            d["expiry_date"] = str(d["expiry_date"])
            data.append(d)

        # Summary counts
        summary = {"EXPIRED": 0, "CRITICAL": 0, "WARNING": 0, "OK": 0}
        for d in data:
            summary[d["expiry_status"]] += 1

        return {"report": "Expiry Report", "summary": summary, "data": data}
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────────────────────────────────────────
# 5. MONTHLY STOCK USAGE
# Total issued per month for a given year
# ─────────────────────────────────────────────────────────────────────────────

def monthly_usage_report(year: int):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT TO_CHAR(created_at, 'YYYY-MM') AS month,
                   p.name AS product_name, p.unit,
                   SUM(st.quantity) AS total_issued
            FROM   stock_transactions st
            JOIN   products p ON p.id = st.product_id
            WHERE  st.transaction_type = 'ISSUE'
              AND  EXTRACT(YEAR FROM st.created_at) = %s
            GROUP  BY month, p.name, p.unit
            ORDER  BY month, p.name
        """, (year,))
        keys = ["month", "product_name", "unit", "total_issued"]
        data = [dict(zip(keys, r)) for r in cursor.fetchall()]
        return {"report": "Monthly Usage Report", "year": year, "data": data}
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────────────────────────────────────────
# 6. ITEM-WISE USAGE REPORT
# Full transaction history for a specific product
# ─────────────────────────────────────────────────────────────────────────────

def item_wise_usage_report(product_id: int, date_from: date, date_to: date):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT st.id, st.transaction_type, st.quantity,
                   st.created_at, u.name AS performed_by,
                   ib.purchase_date, ib.expiry_date
            FROM   stock_transactions st
            JOIN   inventory_batches ib ON ib.id = st.batch_id
            LEFT JOIN users u           ON u.id  = st.performed_by
            WHERE  st.product_id = %s
              AND  DATE(st.created_at) BETWEEN %s AND %s
            ORDER  BY st.created_at DESC
        """, (product_id, date_from, date_to))
        keys = ["transaction_id", "type", "quantity", "date",
                "performed_by", "batch_purchase_date", "batch_expiry_date"]
        data = []
        for r in cursor.fetchall():
            d = dict(zip(keys, r))
            d["date"]                 = str(d["date"])
            d["batch_purchase_date"]  = str(d["batch_purchase_date"])
            d["batch_expiry_date"]    = str(d["batch_expiry_date"]) if d["batch_expiry_date"] else None
            data.append(d)

        # Get product info
        cursor.execute("SELECT name, unit FROM products WHERE id = %s", (product_id,))
        row = cursor.fetchone()
        product_info = {"name": row[0], "unit": row[1]} if row else {}

        return {
            "report":   "Item-wise Usage Report",
            "product":  product_info,
            "from": str(date_from), "to": str(date_to),
            "data": data,
        }
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────────────────────────────────────────
# 7. AUDIT LOG REPORT
# ─────────────────────────────────────────────────────────────────────────────

def audit_log_report(date_from: date, date_to: date, user_id: int = None):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        q = """
            SELECT al.id, u.name AS user_name, al.action_type,
                   al.entity_name, al.entity_id, al.description, al.action_date
            FROM   audit_logs al
            LEFT JOIN users u ON u.id = al.user_id
            WHERE  DATE(al.action_date) BETWEEN %s AND %s
        """
        params = [date_from, date_to]
        if user_id:
            q += " AND al.user_id = %s"; params.append(user_id)
        q += " ORDER BY al.action_date DESC"

        cursor.execute(q, params)
        keys = ["id", "user_name", "action_type", "entity_name",
                "entity_id", "description", "action_date"]
        data = []
        for r in cursor.fetchall():
            d = dict(zip(keys, r))
            d["action_date"] = str(d["action_date"])
            data.append(d)
        return {"report": "Audit Log Report", "from": str(date_from), "to": str(date_to), "data": data}
    finally:
        cursor.close(); conn.close()
