from fastapi import APIRouter, Depends
from typing import Optional
from backend.requests import service
from backend.requests.schemas import RequestCreateSchema, ApproveRequestSchema
from backend.auth.dependencies import get_current_user, require_role

router = APIRouter(prefix="/requests", tags=["Requests"])


@router.get("/", summary="List all requests")
def list_requests(
    status:       Optional[str] = None,
    requested_by: Optional[int] = None,
    current_user=Depends(get_current_user)
):
    # Kitchen staff only see their own requests
    if current_user["role"] == "chef":
        requested_by = current_user["id"]
    return service.get_all_requests(status, requested_by)


@router.post("/", summary="Create a new stock request")
def create_request(body: RequestCreateSchema, current_user=Depends(get_current_user)):
    return service.create_request(
        requested_by = current_user["id"],
        chef_id      = body.chef_id,
        priority     = body.priority,
        reason       = body.reason,
        items        = [i.dict() for i in body.items],
    )


@router.get("/{request_id}", summary="Get full request detail with items and approval history")
def get_request(request_id: int, _=Depends(get_current_user)):
    return service.get_request_detail(request_id)


@router.post("/{request_id}/approve", summary="Approve / Reject / Modify request (Admin)")
def approve_request(
    request_id: int,
    body: ApproveRequestSchema,
    current_user=Depends(require_role("admin"))
):
    return service.approve_request(
        request_id      = request_id,
        approved_by     = current_user["id"],
        approval_status = body.approval_status,
        remarks         = body.remarks,
        items           = [i.dict() for i in body.items] if body.items else [],
    )


@router.post("/{request_id}/issue", summary="Issue stock via FIFO (Store Manager / Admin)")
def issue_request(
    request_id: int,
    current_user=Depends(require_role("admin", "store_manager"))
):
    return service.issue_request(request_id, current_user["id"])
