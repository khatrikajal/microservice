from pydantic import BaseModel
from typing import Optional, List
from datetime import date, datetime


# ─────────────────────────────────────────
# REQUEST CREATION
# ─────────────────────────────────────────

class RequestItemInput(BaseModel):
    product_id:         int
    requested_quantity: int


class RequestCreateSchema(BaseModel):
    chef_id:  Optional[int]  = None
    priority: str            = "medium"   # high / medium / low
    reason:   Optional[str]  = None
    items:    List[RequestItemInput]


# ─────────────────────────────────────────
# APPROVAL
# ─────────────────────────────────────────

class ApprovalItemInput(BaseModel):
    request_item_id:   int
    approved_quantity: int


class ApproveRequestSchema(BaseModel):
    """
    approval_status: APPROVED | REJECTED | MODIFIED
    For MODIFIED — provide per-item approved quantities in items[].
    For APPROVED  — approved_quantity = requested_quantity (auto).
    For REJECTED  — all items get approved_quantity = 0.
    """
    approval_status:   str
    remarks:           Optional[str]            = None
    items:             Optional[List[ApprovalItemInput]] = None


# ─────────────────────────────────────────
# ISSUE
# ─────────────────────────────────────────

class IssueRequestSchema(BaseModel):
    """Trigger FIFO stock deduction for an approved request."""
    pass   # no body needed — all info is in the request record
