from fastapi import HTTPException
from backend.connection.db_connection import get_connection


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _get_request_or_404(cursor, request_id: int):
    cursor.execute("""
        SELECT r.id, r.requested_by, r.chef_id, r.status, r.priority, r.reason,
               r.request_date, r.created_at,
               u.name AS requested_by_name
        FROM   requests r
        LEFT JOIN users u ON u.id = r.requested_by
        WHERE  r.id = %s
    """, (request_id,))
    row = cursor.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Request not found.")
    keys = ["id", "requested_by", "chef_id", "status", "priority", "reason",
            "request_date", "created_at", "requested_by_name"]
    return dict(zip(keys, row))


def _get_request_items(cursor, request_id: int):
    cursor.execute("""
        SELECT ri.id, ri.product_id, p.name AS product_name, p.unit,
               ri.requested_quantity, ri.approved_quantity, ri.fulfilled_quantity
        FROM   request_items ri
        JOIN   products p ON p.id = ri.product_id
        WHERE  ri.request_id = %s
    """, (request_id,))
    keys = ["id", "product_id", "product_name", "unit",
            "requested_quantity", "approved_quantity", "fulfilled_quantity"]
    return [dict(zip(keys, r)) for r in cursor.fetchall()]


# ─────────────────────────────────────────────────────────────────────────────
# FIFO ISSUE LOGIC
# ─────────────────────────────────────────────────────────────────────────────

def _issue_fifo(cursor, request_item_id: int, product_id: int, quantity: int, performed_by: int):
    """Deduct `quantity` from batches in FIFO order. Raises if insufficient stock."""
    cursor.execute("""
        SELECT id, quantity_available
        FROM   inventory_batches
        WHERE  product_id = %s AND quantity_available > 0
        ORDER  BY purchase_date ASC, id ASC
        FOR UPDATE
    """, (product_id,))
    batches = cursor.fetchall()

    remaining = quantity
    for batch_id, available in batches:
        if remaining <= 0:
            break
        deduct = min(available, remaining)

        cursor.execute("""
            UPDATE inventory_batches
            SET    quantity_available = quantity_available - %s
            WHERE  id = %s
        """, (deduct, batch_id))

        cursor.execute("""
            INSERT INTO stock_transactions
                (batch_id, product_id, request_item_id, transaction_type, quantity, performed_by)
            VALUES (%s, %s, %s, 'ISSUE', %s, %s)
        """, (batch_id, product_id, request_item_id, deduct, performed_by))

        remaining -= deduct

    if remaining > 0:
        # Rollback is handled by caller
        raise HTTPException(
            status_code=400,
            detail=f"Insufficient stock for product_id={product_id}. Short by {remaining} units."
        )

    cursor.execute("""
        UPDATE request_items
        SET fulfilled_quantity = requested_quantity
        WHERE id = %s
    """, (request_item_id,))


# ─────────────────────────────────────────────────────────────────────────────
# CREATE REQUEST
# ─────────────────────────────────────────────────────────────────────────────

def create_request(requested_by: int, chef_id, priority, reason, items: list):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        if not items:
            raise HTTPException(status_code=400, detail="Request must have at least one item.")

        cursor.execute("""
            INSERT INTO requests (requested_by, chef_id, priority, reason)
            VALUES (%s, %s, %s, %s) RETURNING id
        """, (requested_by, chef_id, priority, reason))
        request_id = cursor.fetchone()[0]

        for item in items:
            cursor.execute("""
                INSERT INTO request_items (request_id, product_id, requested_quantity)
                VALUES (%s, %s, %s)
            """, (request_id, item["product_id"], item["requested_quantity"]))

        cursor.execute("""
            INSERT INTO audit_logs (user_id, action_type, entity_name, entity_id, description)
            VALUES (%s, 'CREATE', 'requests', %s, 'New stock request created')
        """, (requested_by, request_id))

        conn.commit()
        return {"message": "Request created successfully.", "request_id": request_id}
    except HTTPException:
        conn.rollback(); raise
    except Exception as e:
        conn.rollback(); raise HTTPException(status_code=500, detail=str(e))
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────────────────────────────────────────
# LIST REQUESTS
# ─────────────────────────────────────────────────────────────────────────────

def get_all_requests(status: str = None, requested_by: int = None):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        q = """
            SELECT r.id, r.status, r.priority, r.reason, r.request_date, r.created_at,
                   u.name  AS requested_by_name,
                   c.name  AS chef_name
            FROM   requests r
            LEFT JOIN users u ON u.id = r.requested_by
            LEFT JOIN users c ON c.id = r.chef_id
            WHERE 1=1
        """
        p = []
        if status:
            q += " AND r.status = %s"; p.append(status)
        if requested_by:
            q += " AND r.requested_by = %s"; p.append(requested_by)
        q += " ORDER BY r.created_at DESC"
        cursor.execute(q, p)
        keys = ["id", "status", "priority", "reason", "request_date", "created_at",
                "requested_by_name", "chef_name"]
        return [dict(zip(keys, r)) for r in cursor.fetchall()]
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────────────────────────────────────────
# GET REQUEST DETAIL (with items)
# ─────────────────────────────────────────────────────────────────────────────

def get_request_detail(request_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        req   = _get_request_or_404(cursor, request_id)
        items = _get_request_items(cursor, request_id)

        # Get approval history
        cursor.execute("""
            SELECT ra.id, ra.approval_status, ra.modified_quantity, ra.remarks,
                   ra.approval_date, u.name AS approved_by_name
            FROM   request_approvals ra
            LEFT JOIN users u ON u.id = ra.approved_by
            WHERE  ra.request_id = %s
            ORDER  BY ra.approval_date DESC
        """, (request_id,))
        akeys = ["id", "approval_status", "modified_quantity", "remarks", "approval_date", "approved_by_name"]
        approvals = [dict(zip(akeys, r)) for r in cursor.fetchall()]

        return {**req, "items": items, "approvals": approvals}
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────────────────────────────────────────
# APPROVE / REJECT / MODIFY REQUEST
# ─────────────────────────────────────────────────────────────────────────────

def approve_request(request_id: int, approved_by: int, approval_status: str, remarks: str, items: list):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        req = _get_request_or_404(cursor, request_id)
        if req["status"] != "PENDING":
            raise HTTPException(status_code=400, detail=f"Request is already '{req['status']}'. Only PENDING requests can be actioned.")

        if approval_status not in ("APPROVED", "REJECTED", "MODIFIED"):
            raise HTTPException(status_code=400, detail="Invalid approval_status.")

        req_items = _get_request_items(cursor, request_id)

        # Build approved_quantity per item
        item_map = {i["id"]: i for i in req_items}
        override = {i["request_item_id"]: i["approved_quantity"] for i in (items or [])}

        for ri in req_items:
            if approval_status == "APPROVED":
                aq = ri["requested_quantity"]
            elif approval_status == "REJECTED":
                aq = 0
            else:  # MODIFIED
                aq = override.get(ri["id"], ri["requested_quantity"])

            cursor.execute(
                "UPDATE request_items SET approved_quantity = %s WHERE id = %s",
                (aq, ri["id"])
            )

        # Update request status
        new_status = "APPROVED" if approval_status in ("APPROVED", "MODIFIED") else "REJECTED"
        cursor.execute("UPDATE requests SET status = %s WHERE id = %s", (new_status, request_id))

        # Record approval
        cursor.execute("""
            INSERT INTO request_approvals (request_id, approved_by, approval_status, remarks)
            VALUES (%s, %s, %s, %s)
        """, (request_id, approved_by, approval_status, remarks))

        # Audit log
        cursor.execute("""
            INSERT INTO audit_logs (user_id, action_type, entity_name, entity_id, description)
            VALUES (%s, %s, 'requests', %s, %s)
        """, (approved_by, approval_status, request_id, f"Request {approval_status.lower()} by user {approved_by}"))

        conn.commit()
        return {"message": f"Request {approval_status.lower()} successfully."}
    except HTTPException:
        conn.rollback(); raise
    except Exception as e:
        conn.rollback(); raise HTTPException(status_code=500, detail=str(e))
    finally:
        cursor.close(); conn.close()


# ─────────────────────────────────────────────────────────────────────────────
# ISSUE STOCK (FIFO)
# ─────────────────────────────────────────────────────────────────────────────

def issue_request(request_id: int, issued_by: int):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        req = _get_request_or_404(cursor, request_id)

        if req["status"] != "APPROVED":
            raise HTTPException(status_code=400, detail="Only APPROVED requests can be issued.")

        req_items = _get_request_items(cursor, request_id)

        for item in req_items:
            qty = item["approved_quantity"] or item["requested_quantity"]
            if qty > 0:
                _issue_fifo(cursor, item["id"], item["product_id"], qty, issued_by)

        # Update request status to ISSUED
        cursor.execute("UPDATE requests SET status = 'ISSUED' WHERE id = %s", (request_id,))

        # Audit log
        cursor.execute("""
            INSERT INTO audit_logs (user_id, action_type, entity_name, entity_id, description)
            VALUES (%s, 'ISSUE', 'requests', %s, 'Stock issued via FIFO deduction')
        """, (issued_by, request_id))

        conn.commit()
        return {"message": "Stock issued successfully via FIFO."}
    except HTTPException:
        conn.rollback(); raise
    except Exception as e:
        conn.rollback(); raise HTTPException(status_code=500, detail=str(e))
    finally:
        cursor.close(); conn.close()
