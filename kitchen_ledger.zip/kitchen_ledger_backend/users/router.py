from fastapi import APIRouter, Depends
from typing import Optional
from backend.users import service
from backend.users.schemas import UserUpdateSchema, ChangePasswordSchema
from backend.auth.dependencies import get_current_user, require_role

router = APIRouter(prefix="/users", tags=["Users"])


@router.get("/", summary="List all users (Admin only)")
def list_users(
    is_active: Optional[bool] = None,
    _=Depends(require_role("admin"))
):
    return service.get_all_users(is_active)


@router.get("/chefs", summary="List all chefs for dropdown")
def list_chefs(_=Depends(get_current_user)):
    return service.get_chefs()


@router.get("/me", summary="Get current user profile")
def get_me(current_user=Depends(get_current_user)):
    return service.get_user_by_id(current_user["id"])


@router.get("/{user_id}", summary="Get user by ID (Admin only)")
def get_user(user_id: int, _=Depends(require_role("admin"))):
    return service.get_user_by_id(user_id)


@router.put("/{user_id}", summary="Update user (Admin only)")
def update_user(user_id: int, body: UserUpdateSchema, _=Depends(require_role("admin"))):
    return service.update_user(user_id, body.name, body.contact, body.role)


@router.patch("/{user_id}/deactivate", summary="Deactivate user (Admin only)")
def deactivate_user(user_id: int, _=Depends(require_role("admin"))):
    return service.deactivate_user(user_id)


@router.patch("/{user_id}/activate", summary="Activate user (Admin only)")
def activate_user(user_id: int, _=Depends(require_role("admin"))):
    return service.activate_user(user_id)


@router.post("/change-password", summary="Change own password")
def change_password(body: ChangePasswordSchema, current_user=Depends(get_current_user)):
    return service.change_password(current_user["id"], body.current_password, body.new_password)
