from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime


class UserUpdateSchema(BaseModel):
    name:    Optional[str]   = None
    contact: Optional[str]   = None
    role:    Optional[str]   = None


class UserResponseSchema(BaseModel):
    id:         int
    name:       str
    email:      str
    role:       str
    contact:    Optional[str]
    is_active:  bool
    created_at: datetime


class ChangePasswordSchema(BaseModel):
    current_password: str
    new_password:     str
