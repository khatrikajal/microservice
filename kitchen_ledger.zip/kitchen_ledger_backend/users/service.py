from fastapi import HTTPException
from backend.connection.db_connection import get_connection
from backend.auth.utils import hash_password, verify_password


def get_all_users(is_active: bool = None):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        query = "SELECT id, name, email, role, contact, is_active, created_at FROM users"
        params = []
        if is_active is not None:
            query += " WHERE is_active = %s"
            params.append(is_active)
        query += " ORDER BY created_at DESC"
        cursor.execute(query, params)
        rows = cursor.fetchall()
        keys = ["id", "name", "email", "role", "contact", "is_active", "created_at"]
        return [dict(zip(keys, r)) for r in rows]
    finally:
        cursor.close(); conn.close()


def get_user_by_id(user_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "SELECT id, name, email, role, contact, is_active, created_at FROM users WHERE id = %s",
            (user_id,)
        )
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="User not found.")
        keys = ["id", "name", "email", "role", "contact", "is_active", "created_at"]
        return dict(zip(keys, row))
    finally:
        cursor.close(); conn.close()


def get_chefs():
    """Returns all users with role='chef' for dropdowns."""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "SELECT id, name, email, contact FROM users WHERE role = 'chef' AND is_active = TRUE ORDER BY name"
        )
        rows = cursor.fetchall()
        return [{"id": r[0], "name": r[1], "email": r[2], "contact": r[3]} for r in rows]
    finally:
        cursor.close(); conn.close()


def update_user(user_id: int, name: str = None, contact: str = None, role: str = None):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        fields, params = [], []
        if name    is not None: fields.append("name = %s");    params.append(name)
        if contact is not None: fields.append("contact = %s"); params.append(contact)
        if role    is not None: fields.append("role = %s");    params.append(role)
        if not fields:
            raise HTTPException(status_code=400, detail="No fields to update.")
        params.append(user_id)
        cursor.execute(f"UPDATE users SET {', '.join(fields)} WHERE id = %s", params)
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="User not found.")
        conn.commit()
        return {"message": "User updated successfully."}
    except HTTPException:
        conn.rollback(); raise
    finally:
        cursor.close(); conn.close()


def deactivate_user(user_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("UPDATE users SET is_active = FALSE WHERE id = %s", (user_id,))
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="User not found.")
        conn.commit()
        return {"message": "User deactivated successfully."}
    except HTTPException:
        conn.rollback(); raise
    finally:
        cursor.close(); conn.close()


def activate_user(user_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("UPDATE users SET is_active = TRUE WHERE id = %s", (user_id,))
        conn.commit()
        return {"message": "User activated successfully."}
    except HTTPException:
        conn.rollback(); raise
    finally:
        cursor.close(); conn.close()


def change_password(user_id: int, current_password: str, new_password: str):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT password_hash FROM users WHERE id = %s", (user_id,))
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="User not found.")
        if not verify_password(current_password, row[0]):
            raise HTTPException(status_code=400, detail="Current password is incorrect.")
        cursor.execute(
            "UPDATE users SET password_hash = %s WHERE id = %s",
            (hash_password(new_password), user_id)
        )
        conn.commit()
        return {"message": "Password changed successfully."}
    except HTTPException:
        conn.rollback(); raise
    finally:
        cursor.close(); conn.close()
